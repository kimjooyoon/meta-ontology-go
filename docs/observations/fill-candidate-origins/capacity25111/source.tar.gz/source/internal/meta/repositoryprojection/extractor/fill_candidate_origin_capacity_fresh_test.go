package extractor

import (
	"os"
	"testing"
)

func TestFillCandidateOriginCapacity25111(t *testing.T) {
	root := os.Getenv("GOOO_FRESH_FIELD_ROOT")
	if root == "" {
		root = "../../../.."
	}
	targets := []string{"cmd/gooo#runBodyOrigins", "cmd/gooo#writeBodyFillCandidateOrigins",
		"internal/bodycodegen#InspectSourceFillCandidateOrigins", "internal/bodycodegen#sourceFillCandidateOriginRow",
		"internal/bodycodegen#SourceFillCandidateOriginInputs"}
	requireNamedCapacities(t, root, targets)
	t.Log("candidate25111:all5 changed production declarations;unchanged75-line rendered helper cap;no producer/model execution")
}
