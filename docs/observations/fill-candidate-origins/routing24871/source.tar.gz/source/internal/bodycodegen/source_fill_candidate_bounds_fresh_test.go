package bodycodegen

import (
	"fmt"
	"strconv"
	"strings"
	"testing"
)

func candidateBoundarySource24817(count int) []byte {
	var b strings.Builder
	b.WriteString("package candidate24817\nnamespace candidate24817\nentity Integer id \"urn:candidate24817:integer\"\n")
	b.WriteString("activity Choose(Integer)->Integer computes \"return __GOOO_BODY_HOLE_h0__\" assembling {\n source_fill intent \"Inspect source boundaries.\" {\n")
	for i := 0; i < count; i++ {
		fmt.Fprintf(&b, "hole \"h%d\"\n", i)
	}
	b.WriteString(`candidate "\u0062ad24817" {` + "\n")
	for i := 0; i < count; i++ {
		fmt.Fprintf(&b, "fill \"h%d\" %s\n", i, strconv.Quote(`"메모\\t24817"`))
	}
	b.WriteString("}\n}\ncase \"19\" -> \"29\"\n}\n")
	return []byte(b.String())
}

func TestSourceCandidateBoundaries24817(t *testing.T) {
	source := candidateBoundarySource24817(16)
	r, err := InspectSourceFillCandidateOrigins("경계24817.gooo", source, "Choose", "bad24817")
	if err != nil || len(r.Rows) != 16 || r.UnresolvedRows != 15 || r.Status != "UNRESOLVED" || r.Rows[0].TemplateSource == nil {
		t.Fatal("sixteen-hole boundary", r, err)
	}
	if string(source[r.CandidateSource.Start:r.CandidateSource.End]) != `\u0062ad24817` {
		t.Fatal("escaped candidate identity range", r.CandidateSource)
	}
	for _, row := range r.Rows {
		raw := string(source[row.ExpressionSource.Start:row.ExpressionSource.End])
		decoded, err := strconv.Unquote(`"` + raw + `"`)
		if err != nil || decoded != row.Expression || !strings.Contains(raw, `\"`) {
			t.Fatal("escaped expression lost raw byte origin", raw, decoded, row, err)
		}
	}
	if _, err := SourceFillCandidateOriginInputs(r, "origin/boundary24817:Inspect"); err != nil {
		t.Fatal("sixteen primitive rows", err)
	}
	if _, err := InspectSourceFillCandidateOrigins("too-many24817.gooo", candidateBoundarySource24817(17), "Choose", "bad24817"); err == nil {
		t.Fatal("seventeenth hole silently dropped")
	}
	grammar := []byte(`package grammar24817
namespace grammar24817
entity Integer id "urn:grammar24817:integer"
activity Choose(Integer)->Integer computes "return __GOOO_BODY_HOLE_value__" assembling {
 source_fill intent "Inspect grammar provenance." {
  hole "value"
  derive grammar "integer-offset-constant/v1" max_expressions "3" max_candidates "3"
 }
 case "19" -> "29"
}
`)
	if _, err := InspectSourceFillCandidateOrigins("grammar24817.gooo", grammar, "Choose", "derived24817"); err == nil || !strings.Contains(err.Error(), "generated grammar") {
		t.Fatal("grammar candidate invented a direct assignment location", err)
	}
	if _, err := InspectSourceFillCandidateOrigins("large24817.gooo", []byte(strings.Repeat(" ", (128<<10)+1)), "Choose", "bad24817"); err == nil {
		t.Fatal("source size boundary ignored")
	}
	t.Log("boundary24817:16 rows retained with15 explicit unresolved uses;17 holes/derived grammar/oversized source refused;escaped candidate and quoted Unicode expression ranges exact;model0")
}
