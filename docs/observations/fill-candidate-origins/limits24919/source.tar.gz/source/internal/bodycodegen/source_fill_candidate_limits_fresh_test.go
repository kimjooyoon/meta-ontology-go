package bodycodegen

import (
	"fmt"
	"strconv"
	"strings"
	"testing"
)

func candidateBoundarySource24919(count int) []byte {
	var b strings.Builder
	b.WriteString("package candidate24919\nnamespace candidate24919\nentity Integer id \"urn:candidate24919:integer\"\n")
	b.WriteString("activity Choose(Integer)->Integer computes \"return __GOOO_BODY_HOLE_h0__\" assembling {\n source_fill intent \"Inspect source boundaries.\" {\n")
	for i := 0; i < count; i++ {
		fmt.Fprintf(&b, "hole \"h%d\"\n", i)
	}
	b.WriteString(`candidate "\u0062ad24919" {` + "\n")
	for i := 0; i < count; i++ {
		fmt.Fprintf(&b, "fill \"h%d\" %s\n", i, strconv.Quote(`"메모\\t24919"`))
	}
	b.WriteString("}\n}\ncase \"19\" -> \"29\"\n}\n")
	return []byte(b.String())
}

func TestSourceCandidateBoundaries24919(t *testing.T) {
	source := candidateBoundarySource24919(8)
	r, err := InspectSourceFillCandidateOrigins("경계24919.gooo", source, "Choose", "bad24919")
	if err != nil || len(r.Rows) != 8 || r.UnresolvedRows != 7 || r.Status != "UNRESOLVED" || r.Rows[0].TemplateSource == nil {
		t.Fatal("eight-hole boundary", r, err)
	}
	if string(source[r.CandidateSource.Start:r.CandidateSource.End]) != `\u0062ad24919` {
		t.Fatal("escaped candidate identity range", r.CandidateSource)
	}
	for _, row := range r.Rows {
		raw := string(source[row.ExpressionSource.Start:row.ExpressionSource.End])
		decoded, err := strconv.Unquote(`"` + raw + `"`)
		if err != nil || decoded != row.Expression || !strings.Contains(raw, `\"`) {
			t.Fatal("escaped expression lost raw byte origin", raw, decoded, row, err)
		}
	}
	if _, err := SourceFillCandidateOriginInputs(r, "origin/boundary24919:Inspect"); err != nil {
		t.Fatal("eight primitive rows", err)
	}
	if _, err := InspectSourceFillCandidateOrigins("too-many24919.gooo", candidateBoundarySource24919(9), "Choose", "bad24919"); err == nil {
		t.Fatal("ninth hole silently dropped")
	}
	grammar := []byte(`package grammar24919
namespace grammar24919
entity Integer id "urn:grammar24919:integer"
activity Choose(Integer)->Integer computes "return __GOOO_BODY_HOLE_value__" assembling {
 source_fill intent "Inspect grammar provenance." {
  hole "value"
  derive grammar "integer-offset-constant/v1" max_expressions "3" max_candidates "3"
 }
 case "19" -> "29"
}
`)
	if _, err := InspectSourceFillCandidateOrigins("grammar24919.gooo", grammar, "Choose", "derived24919"); err == nil || !strings.Contains(err.Error(), "generated grammar") {
		t.Fatal("grammar candidate invented a direct assignment location", err)
	}
	if _, err := InspectSourceFillCandidateOrigins("large24919.gooo", []byte(strings.Repeat(" ", (128<<10)+1)), "Choose", "bad24919"); err == nil {
		t.Fatal("source size boundary ignored")
	}
	t.Log("boundary24919:8 rows retained with7 explicit unresolved uses;9 holes/derived grammar/oversized source refused;escaped candidate and quoted Unicode expression ranges exact;model0")
}
