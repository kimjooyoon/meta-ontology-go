package extractor

import (
	"os"
	"testing"
)

func TestReturnChoiceCapacity22373(t *testing.T) {
	root := os.Getenv("GOOO_FRESH_FIELD_ROOT")
	if root == "" {
		root = "../../../.."
	}
	targets := []string{
		"internal/bodycodegen#BindBodyReturnSources",
		"internal/bodycodegen#EqualRetainedReturnOrigins",
		"internal/bodycodegen#InspectRecordChoiceDeclarationOrigins",
		"internal/bodycodegen#VerifyIRBodySearchProjection",
		"internal/bodycodegen#WalkReturnSyntax",
		"internal/bodycodegen#bodyMayUseLength",
		"internal/bodycodegen#bodyProjection.captureReturnOrigins",
		"internal/bodycodegen#bodyProjection.lower",
		"internal/bodycodegen#bodyReturnCapture.captureTyped",
		"internal/bodycodegen#bodyReturnCapture.emitted",
		"internal/bodycodegen#compareSourceFillReplay",
		"internal/bodycodegen#emitRecordAssembly",
		"internal/bodycodegen#generateRouteWithCalls",
		"internal/bodycodegen#normalizeLengthIntegerContexts",
		"internal/bodycodegen#projectBodyOrigins",
		"internal/bodycodegen#realizeRecordAssemblyProjection",
		"internal/bodycodegen#recordAssemblyPlan.choiceOrigins",
		"internal/bodycodegen#recordChoiceLiteralOrigin",
		"internal/bodycodegen#replayTypedPathProjection",
		"internal/bodycodegen#typecheckAndLowerRecords",
		"internal/bodyexecution#buildCompositionFieldProjection",
		"internal/bodyexecution#compositionFieldBindings",
		"internal/bodyexecution#compositionFieldInventory.addReturns",
		"internal/bodyexecution#compositionFieldProjection.collectFunction",
		"internal/bodyexecution#compositionFieldProjection.collectReturnParts",
		"internal/bodyexecution#compositionFieldProjection.collectReturnWrite",
		"internal/bodyexecution#compositionFieldRenderer.node",
		"internal/bodyexecution#compositionFieldRenderer.returnWrite",
		"internal/bodyexecution#compositionSourceReturns",
		"internal/bodyexecution#fieldFunctionReturns",
		"internal/bodyexecution#nativeOriginPage.fieldFileLocation",
		"internal/bodyexecution#observedCompositionFieldProjection",
		"internal/bodyexecution#unparenthesizedFieldValue",
		"internal/bodyexecution#validateFieldChoiceSource",
		"internal/bodyexecution#validateFieldFileSources",
		"internal/bodyexecution#validateFieldInventory",
		"internal/bodyexecution#validateFieldReturnSources",
		"internal/bodyexecution#validateFieldSources",
		"internal/packageruntime/workspaceexecution#bindWorkspaceFieldFileSources",
		"internal/packageruntime/workspaceexecution#mappedRecordChoiceLocation",
		"internal/packageruntime/workspaceexecution#recordChoiceTemplateLocation",
		"internal/packageruntime/workspaceexecution#unmappedRecordChoiceLocation",
		"internal/packageruntime/workspaceexecution#workspaceRecordChoiceOrigin",
		"internal/packageruntime/workspaceexecution#workspaceRecordChoiceSource",
	}
	requireNamedCapacities(t, root, targets)
	t.Log("required changed production declarations", len(targets), "unchanged75-line generated helper cap;declaration identity across package files;producer/model0")
}
