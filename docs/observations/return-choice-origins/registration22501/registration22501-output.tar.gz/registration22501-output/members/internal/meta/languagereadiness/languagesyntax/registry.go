package languagesyntax

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"reflect"

	"github.com/kimjooyoon/meta-ontology-go/internal/meta/languagepackageexecution"
	"github.com/kimjooyoon/meta-ontology-go/internal/meta/languagereadiness/languagesyntax/replay"
)

func expectedRegistry() Registry {
	valid := func(id, path string) CaseDefinition {
		return CaseDefinition{ID: id, Path: path, Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability}
	}
	ordered := func(id, path string) CaseDefinition {
		item := valid(id, path)
		item.OrderedCollections = true
		return item
	}
	invalid := func(id, path, diagnostic string) CaseDefinition {
		return CaseDefinition{ID: id, Path: path, Kind: KindInvalid, ExpectedDecision: DecisionClosed, ExpectedDiagnostic: diagnostic, ProofChoice: "REGRESSION", MetaOperation: "reject-invalid-syntax", Scope: ScopeLanguageCapability}
	}
	governance := func(id, path string) CaseDefinition {
		return CaseDefinition{ID: id, Path: path, Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeGovernanceObservation}
	}
	entityFields := valid("entity-fields-v1", "examples/entity-fields-v1/main.gooo")
	entityFields.EntityFields = true
	ciTimeCausality := valid("ci-time-causality", "examples/ci-time-causality/main.gooo")
	ciTimeCausality.ImplicitActivityPorts = true
	packageUnit := PackageDefinition{ID: "billing-package", Path: "examples/billing-package", Members: []string{"examples/billing-package/activity.gooo", "examples/billing-package/entities.gooo"}, Entry: "PayOrder", ReportSchema: languagepackageexecution.ReportSchema, MetaReducer: "languagepackageexecution.Evaluate", SourceFilesIndicator: "PACKAGE_SOURCE_FILES", ExecutionIndicator: "PACKAGE_EXECUTIONS"}
	symbolicUnit := PackageDefinition{ID: "symbolic-invocation-schema", Path: "examples/symbolic-invocation-schema", Members: []string{"examples/symbolic-invocation-schema/activity.gooo", "examples/symbolic-invocation-schema/entities.gooo", "examples/symbolic-invocation-schema/reader-request.gooo"}, Entry: "Checkout", ReportSchema: languagepackageexecution.ReportSchema, MetaReducer: "languagepackageexecution.Evaluate", SourceFilesIndicator: "PACKAGE_SOURCE_FILES", ExecutionIndicator: "PACKAGE_EXECUTIONS"}
	selfImprovementObservationUnit := PackageDefinition{ID: "self-improvement-observation", Path: "examples/self-improvement-observation", Members: []string{"examples/self-improvement-observation/observation.gooo"}, Entry: "DeclareOperationIntent", ReportSchema: languagepackageexecution.ReportSchema, MetaReducer: "languagepackageexecution.Evaluate", SourceFilesIndicator: "PACKAGE_SOURCE_FILES", ExecutionIndicator: "PACKAGE_EXECUTIONS"}
	partialReuseUnit := PackageDefinition{ID: "self-improvement-partial-reuse", Path: "examples/self-improvement-partial-reuse", Members: []string{"examples/self-improvement-partial-reuse/main.gooo"}, Entry: "CreateReceipt", ReportSchema: languagepackageexecution.ReportSchema, MetaReducer: "languagepackageexecution.Evaluate", SourceFilesIndicator: "PACKAGE_SOURCE_FILES", ExecutionIndicator: "PACKAGE_EXECUTIONS"}
	return Registry{Schema: RegistrySchema, ProjectionUnits: expectedProjectionUnits(), Cases: []CaseDefinition{
		valid("billing", "examples/billing/main.gooo"),
		valid("language-test-pass", "examples/language-test/main.gooo"),
		valid("language-test-failing-assertion", "examples/language-test/failing.gooo"),
		valid("bootstrap", "examples/bootstrap/main.gooo"),
		valid("conformance", "examples/conformance/main.gooo"),
		valid("compiler-self-improvement", "examples/compiler-self-improvement/main.gooo"),
		valid("compiler-self-improvement-operation-envelope", "examples/compiler-self-improvement/operation-envelope.gooo"),
		valid("causal-ci-selection", "examples/causal-ci-selection/main.gooo"),
		valid("causal-ci-selection-semantic-intervention", "examples/causal-ci-selection/semantic-intervention.gooo"),
		valid("causal-ci-selection-nonsemantic-intervention", "examples/causal-ci-selection/nonsemantic-intervention.gooo"),
		valid("causal-ci-selection-contradiction-intervention", "examples/causal-ci-selection/contradiction-intervention.gooo"),
		valid("external-capability-authorization-policy", "examples/external-capability-execution/authorization/policy.gooo"),
		valid("activity-cardinality-resolution", "examples/activity-cardinality-resolution/main.gooo"),
		valid("meta-actionability", "examples/meta-actionability/main.gooo"),
		valid("meta-binding-coverage", "examples/meta-binding-coverage/main.gooo"),
		valid("meta-operation-artifact-coverage", "examples/meta-operation-artifact-coverage/main.gooo"),
		valid("meta-policy-compilation", "examples/meta-policy-compilation/policy.gooo"),
		valid("metric-meta-program-closure", "examples/metric-meta-program-closure/main.gooo"),
		valid("metric-meta-program", "examples/metric-meta-program/main.gooo"),
		valid("root-readme-indicator", "examples/root-readme-indicator/main.gooo"),
		valid("self-improvement", "examples/self-improvement/main.gooo"),
		valid("self-improvement-minimal-loop", "examples/self-improvement-minimal-loop/main.gooo"),
		valid("self-improvement-operation-envelope", "examples/self-improvement-minimal-loop/operation-envelope.gooo"),
		valid("self-improvement-candidate", "examples/self-improvement/candidate.gooo"),
		valid("self-improvement-candidate-authorization", "examples/self-improvement/authorization.gooo"),
		valid("self-improvement-transport", "examples/self-improvement/transport.gooo"),
		valid("self-improvement-execution-contract", "examples/self-improvement-execution-contract/contract.gooo"),
		valid("self-improvement-execution-grant", "examples/self-improvement-execution-grant/grant.gooo"),
		valid("language-value-witness", "examples/language-value-witness/main.gooo"),
		valid("language-value-witness-sign", "examples/language-value-witness/sign.gooo"),
		valid("language-value-witness-mod", "examples/language-value-witness/mod.gooo"),
		valid("language-value-witness-neg", "examples/language-value-witness/neg.gooo"),
		valid("language-value-witness-abs", "examples/language-value-witness/abs.gooo"),
		valid("language-value-witness-add", "examples/language-value-witness/add.gooo"),
		valid("language-value-witness-mul", "examples/language-value-witness/mul.gooo"),
		valid("language-value-witness-div", "examples/language-value-witness/div.gooo"),
		valid("language-value-witness-max", "examples/language-value-witness/max.gooo"),
		valid("language-value-witness-min", "examples/language-value-witness/min.gooo"),
		valid("language-value-witness-iszero", "examples/language-value-witness/iszero.gooo"),
		valid("language-value-witness-not", "examples/language-value-witness/not.gooo"),
		valid("language-value-witness-equal", "examples/language-value-witness/equal.gooo"),
		valid("language-value-witness-and", "examples/language-value-witness/and.gooo"),
		valid("language-runtime-binding", "examples/language-runtime-binding/main.gooo"),
		valid("language-runtime-binding-and", "examples/language-runtime-binding/boolean-and.gooo"),
		valid("language-runtime-binding-typed-chain", "examples/language-runtime-binding/typed-chain.gooo"),
		valid("language-runtime-binding-suspend-resume", "examples/language-runtime-binding/suspend-resume.gooo"),
		{ID: "language-record-binding", Path: "examples/language-record-binding/main.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: true},
		valid("self-improvement-value-witness-execution-input", "examples/self-improvement-value-witness-execution-input/contract.gooo"),
		valid("language-operation-catalog", "examples/language-operation-catalog/main.gooo"),
		valid("language-operation-catalog-unknown", "examples/language-operation-catalog/unknown.gooo"),
		valid("claim-resolution-tuple", "cmd/gooo/testdata/claim-resolution/main.gooo"),
		valid("claim-dependency-causality", "cmd/gooo/testdata/claim-dependency/main.gooo"),
		valid("roundtrip-minimal", "internal/detection/roundtrip/testdata/minimal.gooo"),
		valid("directory-kind-ontology", "internal/meta/directorykind/ontology.gooo"),
		valid("directory-partition-ontology", "internal/meta/directorypartition/ontology.gooo"),
		valid("repository-projection-repair", "examples/repository-projection-repair/main.gooo"),
		valid("opentofu-observation", "examples/opentofu-observation/main.gooo"),
		valid("public-self-observation-discovery-policy", "examples/self-improvement-discovery/discovery.gooo"),
		valid("public-self-observation-discovery-project", "examples/self-improvement-discovery/project.gooo"),
		invalid("unknown-keyword", "examples/language-syntax-roundtrip/unknown-keyword.txt", "parse.unexpected-token"),
		invalid("unterminated-string", "examples/language-syntax-roundtrip/unterminated-string.txt", "lex.unterminated-string"),
		invalid("source-execution-invalid", "examples/language-source-execution/invalid.gooo", "parse.unexpected-token"),
		valid("source-splitter-conformance", "examples/source-splitter-conformance/main.gooo"),
		valid("rollback-integrity-activation", "examples/rollback-integrity-activation/main.gooo"),
		valid("vertical-slice-closure-activation", "examples/vertical-slice-closure-activation/main.gooo"),
		valid("workgraph", "examples/workgraph/main.gooo"),
		valid("external-conformance-activation", "examples/external-conformance-activation/main.gooo"),
		valid("gooo-release-publication", "examples/gooo-release-publication/main.gooo"),
		valid("ci-plan", "examples/ci-plan/main.gooo"),
		valid("ci-effort-observation", "examples/ci-effort-observation/main.gooo"),
		ciTimeCausality,
		valid("reproducibility-semantics", "examples/reproducibility-semantics/main.gooo"),
		entityFields,
		valid("temporal-transition-ticket", "examples/temporal-transition-ticket/main.gooo"),
		valid("domain-observation-definition", "examples/domain-observation/definition.gooo"),
		valid("domain-observation-runtime-binding", "examples/domain-observation/main.gooo"),
		valid("domain-observation-incident", "examples/domain-observation/incident.gooo"),
		valid("domain-observation-repair", "examples/domain-observation/repair.gooo"),
		valid("repair-handoff", "examples/repair-handoff/main.gooo"),
		governance("self-improvement-ci-continuation", "examples/self-improvement-ci-continuation/continuation.gooo"),
		governance("domain-completeness-profile", "scripts/domain-completeness/profile.gooo"),
		valid("value-origins-local-candidate", "examples/value-origins/eligibility.gooo"),
		ordered("batch-planner", "examples/batch-planner/main.gooo"),
		ordered("batch-handoff", "examples/batch-handoff/main.gooo"),

		{ID: "native-origin-reader-constructions", Path: "examples/native-origin-reader/constructions/constructions.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-origin-reader-elements", Path: "examples/native-origin-reader/elements/elements.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-origin-reader-links", Path: "examples/native-origin-reader/links/links.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-origin-reader-reads", Path: "examples/native-origin-reader/reads/reads.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-origin-reader-locals", Path: "examples/native-origin-reader/locals/locals.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-origin-reader-local-fill", Path: "examples/native-origin-reader/local-fill/reader.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "derived-origin-grammar-example", Path: "examples/derived-origin/main.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: false},

		{ID: "gooo-origin-coverage-metaprogram", Path: "examples/derived-origin/coverage.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-local-file-origin-reader", Path: "examples/native-origin-reader/local-files/reader.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "workspace-local-file-origin-example", Path: "examples/workspace-local-origins/main.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "typed-field-origin-copy-example", Path: "examples/typed-value-origins/main.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "typed-field-origin-gooo-ancestry", Path: "examples/typed-value-origins/ancestry.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-record-field-history-example", Path: "examples/native-record-fields/main.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-record-field-history-reader", Path: "examples/native-record-fields/reader.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "native-field-lineage-reader", Path: "examples/native-field-lineage/lineage.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "local-field-bridge-example", Path: "examples/local-field-bridge/main.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "local-field-bridge-reader", Path: "examples/local-field-bridge/trace.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "field-source-map-reader", Path: "examples/field-source-map/inspect.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "scoped-origin-coverage-reader", Path: "examples/scoped-origin-coverage/coverage.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "length-aware-summary", Path: "examples/length-aware-summary/summary.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},

		{ID: "assembled-length-summary", Path: "examples/assembled-length-summary/summary.gooo", Kind: KindValid, ExpectedDecision: DecisionPass, ProofChoice: "COHERENCE", MetaOperation: "replay-language-syntax", Scope: ScopeLanguageCapability, EntityFields: false, ImplicitActivityPorts: false, OrderedCollections: true},
	}, PackageUnits: []PackageDefinition{packageUnit, symbolicUnit, selfImprovementObservationUnit, partialReuseUnit}, MetaSources: []string{"internal/meta/syntaxregistration/contract.gooo", "internal/meta/entityfields/entity-fields-meta.gooo", "examples/public-trust-surface/main.gooo", "internal/meta/generation/operation-input-contract.gooo", "internal/meta/generation/callback-preview-contract.gooo", "internal/meta/generation/callback-extraction-contract.gooo", "internal/meta/generation/self_improvement_outcome_contract.gooo", "internal/meta/policycompilation/revision-operation.gooo", "examples/relay-game-contract/main.gooo", "internal/meta/generation/experience_memory_receipt_contract.gooo"}}
}

func decodeRegistry(raw []byte) (Registry, error) {
	registry := Registry{}
	if err := validateJSONKeyUniqueness(raw); err != nil {
		return registry, fmt.Errorf("decode language syntax registry: %w", err)
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&registry); err != nil {
		return registry, fmt.Errorf("decode language syntax registry: %w", err)
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		return registry, fmt.Errorf("decode language syntax registry: trailing content")
	}
	if err := validateCaseScopes(registry); err != nil {
		return registry, err
	}
	if !reflect.DeepEqual(registry, expectedRegistry()) {
		return registry, fmt.Errorf("language syntax registry mismatch")
	}
	return registry, nil
}

func validateJSONKeyUniqueness(raw []byte) error {
	decoder := json.NewDecoder(bytes.NewReader(raw))
	if err := walkJSONValue(decoder); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		if err == nil {
			return fmt.Errorf("trailing JSON value")
		}
		return err
	}
	return nil
}

func walkJSONValue(decoder *json.Decoder) error {
	token, err := decoder.Token()
	if err != nil {
		return err
	}
	delim, ok := token.(json.Delim)
	if !ok {
		return nil
	}
	switch delim {
	case '{':
		seen := map[string]bool{}
		for decoder.More() {
			keyToken, err := decoder.Token()
			if err != nil {
				return err
			}
			key, ok := keyToken.(string)
			if !ok {
				return fmt.Errorf("object key is not a string")
			}
			if seen[key] {
				return fmt.Errorf("duplicate JSON object key %q", key)
			}
			seen[key] = true
			if err := walkJSONValue(decoder); err != nil {
				return err
			}
		}
		_, err := decoder.Token()
		return err
	case '[':
		for decoder.More() {
			if err := walkJSONValue(decoder); err != nil {
				return err
			}
		}
		_, err := decoder.Token()
		return err
	default:
		return fmt.Errorf("unexpected JSON delimiter %q", delim)
	}
}

func CapabilityCaseTotal() int {
	return FixedCapabilityTotal
}

func validateCaseScopes(registry Registry) error {
	if len(registry.Cases) != FixedTotal || FixedCapabilityTotal+FixedGovernanceTotal != FixedTotal {
		return fmt.Errorf("language syntax scope denominator mismatch")
	}
	capability, governance := 0, 0
	governanceIDs, governancePaths := []string{}, []string{}
	for _, definition := range registry.Cases {
		switch definition.Scope {
		case ScopeLanguageCapability:
			capability++
		case ScopeGovernanceObservation:
			governance++
			governanceIDs = append(governanceIDs, definition.ID)
			governancePaths = append(governancePaths, definition.Path)
		default:
			return fmt.Errorf("language syntax case %q has missing or unknown scope", definition.ID)
		}
	}
	if capability != FixedCapabilityTotal || governance != FixedGovernanceTotal ||
		!reflect.DeepEqual(governanceIDs, []string{"self-improvement-ci-continuation", "domain-completeness-profile"}) ||
		!reflect.DeepEqual(governancePaths, []string{"examples/self-improvement-ci-continuation/continuation.gooo", "scripts/domain-completeness/profile.gooo"}) {
		return fmt.Errorf("language syntax scope partition mismatch")
	}
	return nil
}

func unresolvedCases(source Source) []CaseResult {
	results := make([]CaseResult, 0, totalCases)
	for _, definition := range expectedRegistry().Cases {
		item := CaseResult{Definition: definition, Evidence: replay.Result{ObservedDecision: replay.DecisionUnknown}, Status: "UNRESOLVED"}
		item.EvidenceDigest = caseDigest(item, source)
		results = append(results, item)
	}
	return results
}
