package bodyexecution

import (
	"context"
	"encoding/json"
	"testing"
)

func TestLiteralDecisions9137(t *testing.T) {
	const source = `package literaldecisions
namespace literal9137
entity Integer id "urn:gooo:type:integer"
entity Boolean id "urn:gooo:type:boolean"
entity Text id "urn:gooo:type:string"
entity Request id "urn:literal9137:request" fields {
 field left id "urn:literal9137:left" type string required one
 field right id "urn:literal9137:right" type string required one
 field flag id "urn:literal9137:flag" type boolean required one
 field position id "urn:literal9137:position" type integer required one
}
activity Label(Request) -> Text id "urn:literal9137:label" computes "return []string{input.left,input.right}[__GOOO_BODY_HOLE_pick__]" assembling {
 source_fill intent "요청한 위치의 이름을 구성한 목록에서 읽는다" {
  hole "pick"
  candidate "always-left9137" { fill "pick" "0" }
  candidate "requested9137" { fill "pick" "input.position" }
 }
 value_case "[{\"left\":\"봄\",\"right\":\"여름\",\"flag\":true,\"position\":1}]" -> "\"여름\""
 holdout_value_case "[{\"left\":\"가을\",\"right\":\"겨울\",\"flag\":false,\"position\":0}]" -> "\"가을\""
}
activity Flag(Request) -> Boolean id "urn:literal9137:flag-result" computes "return []bool{input.flag,false}[__GOOO_BODY_HOLE_pick__]" assembling {
 source_fill intent "입력에서 받은 불리언을 선택한다" {
  hole "pick"
  candidate "false9137" { fill "pick" "1" }
  candidate "input9137" { fill "pick" "0" }
 }
 value_case "[{\"left\":\"연필\",\"right\":\"책\",\"flag\":true,\"position\":1}]" -> "true"
 holdout_value_case "[{\"left\":\"paper\",\"right\":\"pen\",\"flag\":false,\"position\":0}]" -> "false"
}
activity Empty(Request) -> Integer id "urn:literal9137:empty" computes "let names = []string{}; return int64(len(names))"
`
	suite := CompositionCases{Schema: "gooo/body-composition-cases/v1"}
	for _, probe := range []struct{ input, text, flag string }{
		{`{"left":"꽃","right":"나무","flag":true,"position":1}`, `"나무"`, `true`},
		{`{"left":"하늘","right":"바다","flag":false,"position":0}`, `"하늘"`, `false`},
		{`{"left":"sun","right":"moon","flag":true,"position":1}`, `"moon"`, `true`},
	} {
		suite.Cases = append(suite.Cases, CompositionCase{Inputs: map[string]json.RawMessage{"Label": json.RawMessage(probe.input), "Flag": json.RawMessage(probe.input), "Empty": json.RawMessage(probe.input)}, Expected: map[string]json.RawMessage{"Label": json.RawMessage(probe.text), "Flag": json.RawMessage(probe.flag), "Empty": json.RawMessage(`0`)}})
	}
	program, err := GenerateComposition(context.Background(), "목록결정9137.gooo", []byte(source), suite, "")
	observed := map[string]any{"source": source, "cases": suite, "composition": program}
	defer saveReadObservation(t, "literal9137.json", observed)
	if err != nil {
		t.Fatal("typed literal selection", err)
	}
	runtime, err := ExecuteComposition(context.Background(), "목록결정9137.gooo", []byte(source), program, suite, "")
	observed["runtime"] = runtime
	if err != nil || runtime.FinitePassed != 9 || runtime.FiniteTotal != 9 {
		t.Fatal("three fresh literal programs", err, runtime.FinitePassed)
	}
	if runtime.ReadObservation == nil || runtime.ReadObservation.RecordedReads != 6 || runtime.ReadObservation.UnresolvedReads != 6 || len(runtime.ReadInputs) != 0 {
		t.Fatal("constructed values have source expressions but no input element identity", runtime.ReadObservation)
	}
	for _, site := range runtime.ReadSites {
		if site.Source == nil || site.Source.Status != "MAPPED" {
			t.Fatal("literal source range", site)
		}
	}
	t.Log("literal9137: Text/Boolean selected bodies, empty Text collection, native9/9; six constructed reads explicitly unresolved; model0")
}
