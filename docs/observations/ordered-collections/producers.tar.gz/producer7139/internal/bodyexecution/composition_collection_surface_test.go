package bodyexecution

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"testing"

	"github.com/kimjooyoon/meta-ontology-go/internal/bodycodegen"
)

func TestCollectionSourceOrderAndOrigins7139(t *testing.T) {
	const sum = `let 합계 = 0; for 항목 in input.amounts { if 항목 > 7 { 합계 = 합계 + 항목 } }; return 합계`
	const join = `let 결과 = ""; for 이름 in input.labels { 결과 = 결과 + 이름 }; return 결과`
	source := `package collection7139
namespace collection7139
entity Integer id "urn:gooo:type:integer"
entity Text id "urn:gooo:type:string"
entity Amounts id "urn:collection7139:amounts" fields {
 field amounts id "urn:collection7139:values" type integer required many
}
entity Labels id "urn:collection7139:labels" fields {
 field labels id "urn:collection7139:names" type string required many
}
activity Sum(Amounts) -> Integer id "urn:collection7139:sum" computes ` + strconv.Quote(sum) + `
activity Join(Labels) -> Text id "urn:collection7139:join" computes ` + strconv.Quote(join) + "\n"
	const cases = `{"schema":"gooo/body-composition-cases/v1","cases":[
{"inputs":{"Sum":{"amounts":[2,19,-3,7]},"Join":{"labels":["가","a","나"]}},"expected":{"Sum":19,"Join":"가a나"}},
{"inputs":{"Sum":{"amounts":[]},"Join":{"labels":[]}},"expected":{"Sum":0,"Join":""}},
{"inputs":{"Sum":{"amounts":[9007199254740995,5]},"Join":{"labels":["나","a","가"]}},"expected":{"Sum":9007199254740995,"Join":"나a가"}}
]}`
	suite, err := DecodeCompositionCases([]byte(cases))
	if err != nil {
		t.Fatal(err)
	}
	generated, err := GenerateComposition(context.Background(), "목록7139.gooo", []byte(source), suite, "")
	if err != nil {
		t.Fatal("generate for-in source", err)
	}
	run, err := ExecuteComposition(context.Background(), "목록7139.gooo", []byte(source), generated, suite, nativeTool())
	if err != nil || run.FinitePassed != 6 || run.FiniteTotal != 6 || run.ModelCalls != 0 {
		t.Fatal("for-in native results", err, run.FinitePassed, run.FiniteTotal, run.ModelCalls)
	}
	if len(run.ConditionSites) != 1 {
		t.Fatal("condition site count", len(run.ConditionSites))
	}
	anchor := run.ConditionSites[0].Source
	if anchor == nil || anchor.Status != "MAPPED" || anchor.Expression != "항목 > 7" ||
		sum[anchor.DecodedStart:anchor.DecodedEnd] != "항목 > 7" || generated.GoooSource[anchor.Start:anchor.End] != "항목 > 7" {
		t.Fatal("condition must retain original Korean source positions", anchor)
	}
	flow := bodycodegen.InspectBodyValueOrigins(sum, 1)
	if flow.Status != "PARTIAL" || !slices.Contains(flow.Reasons, "COLLECTION_ELEMENTS_JOINED") || slices.Contains(flow.Reasons, "SOURCE_RANGE_UNAVAILABLE") {
		t.Fatal("collection origin analysis must state its item-joining limit", flow)
	}
	nodes := map[string]bodycodegen.BodyValueOrigin{}
	var condition string
	for _, node := range flow.Nodes {
		nodes[node.ID] = node
		if node.Kind == "condition" {
			condition = node.ID
			if sum[node.Decoded.Start:node.Decoded.End] != "항목 > 7" {
				t.Fatal("value origin condition byte range moved", node)
			}
		}
	}
	seen := map[string]bool{}
	queue := []string{condition}
	inputFound := false
	for len(queue) != 0 {
		id := queue[0]
		queue = queue[1:]
		if seen[id] {
			continue
		}
		seen[id] = true
		node := nodes[id]
		inputFound = inputFound || node.Kind == "input_reference" && node.Name == "input"
		queue = append(queue, node.Inputs...)
	}
	if condition == "" || !inputFound {
		t.Fatal("condition must link through collection element to original input", flow)
	}
	if directory := os.Getenv("GOOO_COLLECTION_OBSERVATION"); directory != "" {
		raw, err := json.MarshalIndent(map[string]any{"source": source, "cases": json.RawMessage(cases), "generation": generated,
			"runtime": run, "body_value_origins": flow, "historical_source_executions": 0}, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(directory, "surface7139.json"), append(raw, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
	t.Log("7139: native6/6, ordered Text and exact Integer collections; Korean condition source range and collection-input origin; model0")
}
