package generator

import (
	"fmt"
	"net/url"
	"strings"
	"unicode"
)

func validateSupportedField(entity Entity, index int, field Field, used map[string]string, seenNames map[string]string, sourceURI string, previousStart int, hasPrevious, allowBoolean, allowInteger, allowOptional, allowMany bool) error {
	context := fmt.Sprintf("entity %q field %d", entity.ID, index)
	if field.ID == "" || field.Name == "" || field.Parent == "" || field.TypeRefID == "" || field.Presence == "" || field.Cardinality == "" {
		return entityFieldsError(entityFieldsIncompleteDiagnostic, field, context+" is missing a required identity, name, type, shape, or parent")
	}
	canonicalID, err := canonicalEntityFieldIdentity(field.ID)
	if err != nil || canonicalID != field.ID {
		return entityFieldsError(entityFieldsIncompleteDiagnostic, field, "field ID must be a canonical absolute identity")
	}
	if previous, exists := used[field.ID]; exists {
		return entityFieldsError(entityFieldsIDCollisionDiagnostic, field, fmt.Sprintf("identity is already used by %s", previous))
	}
	used[field.ID] = "field"
	if field.Parent != entity.ID {
		return entityFieldsError(entityFieldsWrongParentDiagnostic, field, fmt.Sprintf("parent %q does not match entity %q", field.Parent, entity.ID))
	}
	if len(field.Aliases) != 0 {
		return entityFieldsError(entityFieldsUnsupportedShapeDiagnostic, field, "aliases are not part of the bound projection profile")
	}
	if field.Origin != "" && field.Origin != "Source" {
		return entityFieldsError(entityFieldsUnrepresentableDiagnostic, field, fmt.Sprintf("field origin %q is not source-authoritative", field.Origin))
	}
	if field.GoName != "" && field.GoName != field.Name {
		return entityFieldsError(entityFieldsUnrepresentableDiagnostic, field, "Go name must be exactly Field.Name")
	}
	expectedGoType := "string"
	if field.TypeRefID == entityFieldsBooleanTypeID && allowBoolean {
		expectedGoType = "bool"
	} else if field.TypeRefID == entityFieldsIntegerTypeID && allowInteger {
		expectedGoType = "int64"
	}
	if field.Cardinality == "many" && allowMany {
		expectedGoType = "[]" + expectedGoType
	}
	if field.Presence == "optional" && allowOptional {
		expectedGoType = "*" + expectedGoType
	}
	if field.GoType != "" && field.GoType != expectedGoType {
		return entityFieldsError(entityFieldsUnrepresentableDiagnostic, field, "Go type is derived from the profile and cannot be overridden")
	}
	if !isGoIdentifier(field.Name) {
		return entityFieldsError(entityFieldsGoNameCollisionDiagnostic, field, "Field.Name is not a valid Go identifier")
	}
	if previous, exists := seenNames[field.Name]; exists {
		return entityFieldsError(entityFieldsGoNameCollisionDiagnostic, field, fmt.Sprintf("Go name is already used by field %q", previous))
	}
	seenNames[field.Name] = field.ID
	if field.TypeRefID != entityFieldsStringTypeID && !(allowBoolean && field.TypeRefID == entityFieldsBooleanTypeID) && !(allowInteger && field.TypeRefID == entityFieldsIntegerTypeID) {
		return entityFieldsError(entityFieldsUnsupportedTypeDiagnostic, field, fmt.Sprintf("resolved type %q is not in the bound profile", field.TypeRefID))
	}
	validPresence := field.Presence == "required" || allowOptional && field.Presence == "optional"
	if !validPresence || field.Cardinality != "one" && !(allowMany && field.Cardinality == "many") {
		return entityFieldsError(entityFieldsUnsupportedShapeDiagnostic, field, "the bound profile does not support this presence/cardinality shape")
	}
	if err := validateFieldSource(entity, field, sourceURI, previousStart, hasPrevious); err != nil {
		return err
	}
	return nil
}
func canonicalEntityFieldIdentity(raw string) (string, error) {
	value := strings.TrimSpace(raw)
	if value == "" || strings.IndexFunc(value, unicode.IsSpace) >= 0 {
		return "", fmt.Errorf("empty or spaced identity")
	}
	parsed, err := url.Parse(value)
	if err != nil || parsed.Scheme == "" || strings.Contains(value, "://") && parsed.Host == "" {
		return "", fmt.Errorf("identity is not absolute")
	}
	parsed.Scheme = strings.ToLower(parsed.Scheme)
	if parsed.Host != "" {
		parsed.Host = strings.ToLower(parsed.Host)
	}
	return parsed.String(), nil
}
