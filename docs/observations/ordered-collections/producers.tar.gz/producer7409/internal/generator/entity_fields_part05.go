package generator

func prepareEntityFields(ir SemanticIR) SemanticIR {
	prepared := copyIR(ir)
	for entityIndex := range prepared.Entities {
		for fieldIndex := range prepared.Entities[entityIndex].Fields {
			field := &prepared.Entities[entityIndex].Fields[fieldIndex]
			field.GoName = field.Name
			field.GoType = "string"
			if field.TypeRefID == entityFieldsBooleanTypeID {
				field.GoType = "bool"
			} else if field.TypeRefID == entityFieldsIntegerTypeID {
				field.GoType = "int64"
			}
			if field.Cardinality == "many" {
				field.GoType = "[]" + field.GoType
			}
			if field.Presence == "optional" {
				field.GoType = "*" + field.GoType
			}
		}
	}
	return prepared
}
