package generator

import "github.com/kimjooyoon/meta-ontology-go/internal/syntax"

// Project is the convenience entry point for a projection with optional
// previous source.  It is the strongly typed API used by compiler adapters.
func Project(ir SemanticIR, previous []byte) (Result, error) {
	return New(Options{}).Generate(ir, previous)
}

// Generate projects a local SemanticIR with optional previous source.
func Generate(ir SemanticIR, previous []byte) (Result, error) {
	return New(Options{}).Generate(ir, previous)
}

// GenerateWithEntityFieldsSupport is the explicit profile-bound projection
// entry point. It never falls back to the deferred default.
func GenerateWithEntityFieldsSupport(ir SemanticIR, previous []byte, support syntax.EntityFieldsSupport) (Result, error) {
	return New(Options{}).generateWithEntityFieldsSupport(ir, previous, support)
}

// GenerateEntityFieldsV1 projects the exact supported EntityFields profile.
func GenerateEntityFieldsV1(ir SemanticIR, previous []byte) (Result, error) {
	return GenerateWithEntityFieldsSupport(ir, previous, syntax.EntityFieldsV1Support())
}

// GenerateEntityFieldsV2 projects required single string and Boolean fields
// under the separately versioned EntityFields V2 contract.
func GenerateEntityFieldsV2(ir SemanticIR, previous []byte) (Result, error) {
	return GenerateWithEntityFieldsSupport(ir, previous, syntax.EntityFieldsV2Support())
}

// GenerateEntityFieldsV3 projects required single string, Boolean and Integer
// fields under the separately versioned EntityFields V3 contract.
func GenerateEntityFieldsV3(ir SemanticIR, previous []byte) (Result, error) {
	return GenerateWithEntityFieldsSupport(ir, previous, syntax.EntityFieldsV3Support())
}

// GenerateEntityFieldsV4 projects required and optional single scalar fields
// under the separately versioned EntityFields V4 contract.
func GenerateEntityFieldsV4(ir SemanticIR, previous []byte) (Result, error) {
	return GenerateWithEntityFieldsSupport(ir, previous, syntax.EntityFieldsV4Support())
}

// GenerateFrom is a compatibility-friendly one-shot API. Inputs may be a
// SemanticIR, a SemanticIRProvider, or a structurally compatible semantic
// graph supplied by an adapter. The return source and source map are kept
// separate for callers that write the source directly to disk.
func GenerateFrom(input any, options Options) ([]byte, SourceMap, error) {
	ir, err := adaptInput(input)
	if err != nil {
		return nil, SourceMap{}, err
	}
	if options.PackageName != "" {
		ir.Package = options.PackageName
	}
	result, err := New(options).Generate(ir, nil)
	if err != nil {
		return nil, SourceMap{}, err
	}
	return result.Source, result.SourceMap, nil
}

// GenerateFromProjectionV1 adapts a typed or reflective input through the
// same strict compatibility path as GenerateFrom and returns versioned,
// read-only projection metadata. External evidence remains deferred.
func GenerateFromProjectionV1(input any, options Options) (ProjectionMetadataV1, error) {
	ir, err := adaptInput(input)
	if err != nil {
		return ProjectionMetadataV1{}, err
	}
	if options.PackageName != "" {
		ir.Package = options.PackageName
	}
	return generateProjectionV1(New(options), ir, nil)
}

// Generate projects ir into Go.  When previous is non-empty, only owned
// generated regions are replaced or removed.  Marker-outside text and the
// contents of stable handwritten slots are retained byte-for-byte.
func (g Generator) Generate(input SemanticIR, previous []byte) (Result, error) {
	return g.generateWithEntityFieldsSupport(input, previous, checkedEntityFieldsSupport())
}

// GenerateEntityFieldsV5 projects ordered scalar collections with their declared presence.
func GenerateEntityFieldsV5(ir SemanticIR, previous []byte) (Result, error) {
	return GenerateWithEntityFieldsSupport(ir, previous, syntax.EntityFieldsV5Support())
}
