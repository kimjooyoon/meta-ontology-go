package bodycodegen

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

func TestCollectionCandidateAssembly7301(t *testing.T) {
	body := `let 합계 = 0; for 값 in input.amounts { if __GOOO_BODY_HOLE_gate__ { 합계 = 합계 + 값 } }; return Summary{total: 합계, amounts: input.amounts}`
	source := []byte(`package fill7301
namespace fill7301
entity Basket id "urn:fill7301:basket" fields {
 field amounts id "urn:fill7301:amounts" type integer required many
}
entity Summary id "urn:fill7301:summary" fields {
 field total id "urn:fill7301:total" type integer required one
 field amounts id "urn:fill7301:originals" type integer required many
}
activity Compute(Basket) -> Summary id "urn:fill7301:compute" computes ` + strconv.Quote(body) + ` assembling {
 source_fill intent "20 이상인 항목만 더하고 원래 순서를 보존한다" {
  hole "gate"
  candidate "negative7301" { fill "gate" "값 < 0" }
  candidate "twenty7301" { fill "gate" "값 >= 20" }
 }
 value_case "[{\"amounts\":[21,-3,5]}]" -> "{\"amounts\":[21,-3,5],\"total\":21}"
 value_case "[{\"amounts\":[]}]" -> "{\"amounts\":[],\"total\":0}"
 value_case "[{\"amounts\":[-1,26,20]}]" -> "{\"amounts\":[-1,26,20],\"total\":46}"
 value_holdout "[{\"amounts\":[9007199254740999,19]}]" -> "{\"amounts\":[9007199254740999,19],\"total\":9007199254740999}"
}
`)
	spec, err := SourceAssembly(context.Background(), "조립7301.gooo", source, "Compute")
	if err != nil {
		t.Fatal(err)
	}
	result, err := GenerateWithSourceIRBodyFill(context.Background(), "조립7301.gooo", source, "Compute", spec, "", "", IRBodyFillOptions{})
	if err != nil {
		t.Fatal("finite collection assembly", err)
	}
	r := result.Report.BodyFill
	if r == nil || r.SelectedCandidateID != "twenty7301" || r.TestCasesPassed != 3 || r.TestCasesTotal != 3 ||
		r.HoldoutCasesPassed != 1 || r.HoldoutCasesTotal != 1 || r.LocalModelPredictions != 0 || r.ExternalProviderCalls != 0 {
		t.Fatal("selection and separate holdout results", r)
	}
	if len(r.CandidateScores) != 2 || len(result.Report.BodyConditions) != 1 {
		t.Fatal("finite candidates or condition source missing")
	}
	bound, err := BindBodyConditionSources([]byte(result.GoooSource), result.Report.BodyConditions)
	if err != nil || len(bound) != 1 || bound[0].Status != "MAPPED" {
		t.Fatal("selected condition origin", err, bound)
	}
	link := r.SourceOrigin.ConditionOrigin(result.Report.BodyConditions[0], FillOriginRange{bound[0].DecodedStart, bound[0].DecodedEnd})
	found := false
	if link != nil {
		for _, fragment := range link.Fragments {
			if fragment.HoleID == "gate" && fragment.ExpressionSource != nil {
				found = string(source[fragment.ExpressionSource.Start:fragment.ExpressionSource.End]) == "값 >= 20"
			}
		}
	}
	if !found || !strings.Contains(result.GoooSource, "for") {
		t.Fatal("collection condition must cite selected source expression", link)
	}
	if directory := os.Getenv("GOOO_COLLECTION_OBSERVATION"); directory != "" {
		raw, err := json.MarshalIndent(map[string]any{"source": string(source), "result": result, "condition_source": bound,
			"condition_construction": link, "historical_source_executions": 0}, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(directory, "fill7301.json"), append(raw, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
	t.Log("7301: two declared candidates, selected finite cases3/3, disjoint holdout1/1; ordered arrays compared by values; candidate source linked; model0")
}
