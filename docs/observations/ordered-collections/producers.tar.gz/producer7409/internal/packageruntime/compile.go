package packageruntime

import (
	"context"
	"strings"

	"github.com/kimjooyoon/meta-ontology-go/internal/bidir"
	"github.com/kimjooyoon/meta-ontology-go/internal/syntax"
)

type compiledPackage struct {
	image        PackageImage
	activities   []EntryPlan
	declarations []InterfaceDeclaration
}

type parsedPackageSource struct {
	source Source
	file   *syntax.File
	names  []string
}

func compilePackage(spec PackageSpec, dependencies map[string][]Export, includeInterface bool) (compiledPackage, error) {
	compiled := compiledPackage{image: PackageImage{
		Path: spec.Path, Name: spec.Name, Imports: append([]string(nil), spec.Imports...),
	}}
	declarations := map[string]bool{}
	var exports []Export
	var sources []parsedPackageSource
	sourceImports := map[string]bool{}
	activitySources := map[string]*syntax.File{}
	for _, source := range spec.Sources {
		file, names, sourceExports, activities, err := compileSource(spec, source)
		if err != nil {
			return compiledPackage{}, err
		}
		if compiled.image.Namespace != "" && compiled.image.Namespace != file.Namespace.Name {
			return compiledPackage{}, reject("PACKAGE_NAMESPACE_MISMATCH", "package %q", spec.Path)
		}
		compiled.image.Namespace = file.Namespace.Name
		for _, name := range names {
			if declarations[name] {
				return compiledPackage{}, reject("PACKAGE_DECLARATION_DUPLICATE", "%s:%s", spec.Path, name)
			}
			declarations[name] = true
		}
		for _, export := range sourceExports {
			if export.Kind == "activity" {
				activitySources[export.Name] = file
			}
		}
		exports = append(exports, sourceExports...)
		sources = append(sources, parsedPackageSource{source: source, file: file, names: names})
		compiled.image.Declarations += len(names)
		compiled.activities = append(compiled.activities, activities...)
		for _, importDecl := range file.Imports {
			sourceImports[importDecl.Path] = true
		}
	}
	if !sameImportSet(spec.Imports, sourceImports) {
		return compiledPackage{}, reject("PACKAGE_SOURCE_IMPORT_MISMATCH", "%s source imports do not match the workspace manifest", spec.Path)
	}
	entityTypes := make(map[string]string)
	for _, export := range exports {
		if export.Kind == "entity" {
			entityTypes[export.Name] = export.ID
		}
	}
	typeEnvironments := make(map[*syntax.File]map[string]string)
	bareTypes := make(map[string]string)
	for index := range exports {
		if exports[index].Kind != "activity" {
			continue
		}
		file := activitySources[exports[index].Name]
		if typeEnvironments[file] == nil {
			typeEnvironments[file] = make(map[string]string)
		}
		typeEnvironment := typeEnvironments[file]
		resolvedInputs := make([]string, len(exports[index].InputTypes))
		for typeIndex, name := range exports[index].InputTypes {
			resolved, err := resolveSourceEntityType(spec, file, name, entityTypes, dependencies)
			if err != nil {
				return compiledPackage{}, err
			}
			resolvedInputs[typeIndex] = resolved
			typeEnvironment[name] = resolved
			if !strings.Contains(name, ".") {
				bareTypes[name] = resolved
			}
		}
		resolvedOutput, err := resolveSourceEntityType(spec, file, exports[index].OutputType, entityTypes, dependencies)
		if err != nil {
			return compiledPackage{}, err
		}
		typeEnvironment[exports[index].OutputType] = resolvedOutput
		if !strings.Contains(exports[index].OutputType, ".") {
			bareTypes[exports[index].OutputType] = resolvedOutput
		}
		exports[index].InputTypes = resolvedInputs
		exports[index].OutputType = resolvedOutput
	}
	for _, source := range sources {
		bindings, err := resolvePackageBindings(spec, source.file, exports, dependencies, activitySources)
		if err != nil {
			return compiledPackage{}, err
		}
		compiled.image.Bindings = append(compiled.image.Bindings, bindings...)
	}
	identities := make(map[string]string)
	for _, source := range sources {
		fileForLowering, fieldTypes, err := resolveSourceFieldTypes(spec, source.file, entityTypes, dependencies)
		if err != nil {
			return compiledPackage{}, err
		}
		fileForLowering.Bindings = sameFileBindings(fileForLowering.Bindings, source.file)
		types := sourceTypeEnvironment(bareTypes, typeEnvironments[source.file])
		fileWithTypes := appendEntityTypeEnvironment(fileForLowering, types)
		ir, err := bidir.LowerContextWithEntityFieldsSupport(context.Background(), fileWithTypes, syntax.EntityFieldsSupportForFile(fileWithTypes, bidir.EntityFieldsV4Support()))
		if err != nil {
			return compiledPackage{}, reject("PACKAGE_SOURCE_INVALID", "lower source %q: %v", source.source.Filename, err)
		}
		projected := projectSourceInterface(source, ir)
		for _, declaration := range projected {
			if previous, exists := identities[declaration.ID]; exists {
				return compiledPackage{}, reject("PACKAGE_DECLARATION_ID_DUPLICATE",
					"%s:%s and %s share identity %q", spec.Path, declaration.Name, previous, declaration.ID)
			}
			identities[declaration.ID] = declaration.Name
		}
		if includeInterface {
			compiled.declarations = append(compiled.declarations, projected...)
		}
		compiled.image.Sources = append(compiled.image.Sources, SourceImage{
			Filename: source.source.Filename, SourceDigest: digestValue(source.source.Content),
			SemanticDigest: "sha256:" + ir.StableHash(), Declarations: len(source.names),
			FieldTypes: fieldTypes,
		})
	}
	sortExports(exports)
	compiled.image.Exports = exports
	compiled.image.SemanticDigest = digestValue(struct {
		Path, Namespace string
		Sources         []SourceImage
		Exports         []Export
		Bindings        []PackageBinding
	}{spec.Path, compiled.image.Namespace, compiled.image.Sources, compiled.image.Exports, compiled.image.Bindings})
	return compiled, nil
}

func sameImportSet(manifestImports []string, sourceImports map[string]bool) bool {
	if len(sourceImports) == 0 {
		return true
	}
	if len(manifestImports) != len(sourceImports) {
		return false
	}
	for _, importPath := range manifestImports {
		if !sourceImports[importPath] {
			return false
		}
	}
	return true
}
