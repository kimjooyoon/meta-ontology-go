package bidir

import (
	"fmt"
	"github.com/kimjooyoon/meta-ontology-go/internal/semantic"
	"github.com/kimjooyoon/meta-ontology-go/internal/syntax"
	"strings"
)

func classifyEntityFieldsModelError(err error, span SourceSpan) error {
	message := err.Error()
	switch {
	case strings.Contains(message, semantic.ErrAmbiguousType.Error()):
		return entityFieldsError(EntityFieldsAmbiguousTypeDiagnostic, message, span, semantic.ErrAmbiguousType)
	case strings.Contains(message, semantic.ErrUnknownType.Error()):
		return entityFieldsError(EntityFieldsUnknownTypeDiagnostic, message, span, semantic.ErrUnknownType)
	case strings.Contains(message, "parent is"):
		return entityFieldsError(EntityFieldsWrongParentDiagnostic, message, span, ErrInvalidField)
	default:
		return err
	}
}
func validateEntityFieldsProfileField(field Field, registry semantic.TypeRegistry, support EntityFieldsSupport) error {
	normalized, err := normalizeField(field, field.Parent, EntityKind, registry)
	if err != nil {
		return classifyEntityFieldsTypeError(field, err)
	}
	typeID, err := resolvedFieldTypeID(normalized, normalized.TypeRef, registry)
	if err != nil {
		return classifyEntityFieldsTypeError(field, err)
	}
	stringType := typeID == semantic.BuiltinStringTypeID
	booleanType := typeID == semantic.BuiltinBooleanTypeID && (support.Profile.ID == syntax.EntityFieldsV2ProfileID || support.Profile.ID == syntax.EntityFieldsV3ProfileID || support.Profile.ID == syntax.EntityFieldsV4ProfileID || support.Profile.ID == syntax.EntityFieldsV5ProfileID)
	integerType := typeID == semantic.BuiltinIntegerTypeID && (support.Profile.ID == syntax.EntityFieldsV3ProfileID || support.Profile.ID == syntax.EntityFieldsV4ProfileID || support.Profile.ID == syntax.EntityFieldsV5ProfileID)
	if !stringType && !booleanType && !integerType {
		return entityFieldsProfileError(field, EntityFieldsUnsupportedTypeDiagnostic, fmt.Sprintf("resolved type %q is not in the bound profile", typeID))
	}
	validPresence := normalized.Presence == FieldPresenceRequired || (support.Profile.ID == syntax.EntityFieldsV4ProfileID || support.Profile.ID == syntax.EntityFieldsV5ProfileID) && normalized.Presence == FieldPresenceOptional
	validCardinality := normalized.Cardinality == FieldCardinalityOne || support.Profile.ID == syntax.EntityFieldsV5ProfileID && normalized.Cardinality == FieldCardinalityMany
	if !validPresence || !validCardinality {
		return entityFieldsProfileError(field, EntityFieldsUnsupportedShapeDiagnostic, "the bound profile does not support this presence/cardinality shape")
	}
	return nil
}
func classifyEntityFieldsTypeError(field Field, err error) error {
	message := err.Error()
	switch {
	case strings.Contains(message, semantic.ErrAmbiguousType.Error()):
		return entityFieldsProfileError(field, EntityFieldsAmbiguousTypeDiagnostic, message)
	case strings.Contains(message, semantic.ErrUnknownType.Error()):
		return entityFieldsProfileError(field, EntityFieldsUnknownTypeDiagnostic, message)
	default:
		return err
	}
}
func modelHasFields(nodes []Node) bool {
	for _, node := range nodes {
		if len(node.Fields) != 0 {
			return true
		}
	}
	return false
}
func firstModelFieldSpan(nodes []Node) SourceSpan {
	for _, node := range nodes {
		if len(node.Fields) != 0 {
			return node.Fields[0].Span
		}
	}
	return SourceSpan{}
}
func documentHasFields(document Document) bool {
	for _, declaration := range document.Declarations {
		if len(declaration.Fields) != 0 {
			return true
		}
	}
	return false
}
