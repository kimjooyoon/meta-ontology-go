package bodyexecution

import (
	"context"
	"fmt"
	"slices"
	"time"

	"github.com/kimjooyoon/meta-ontology-go/internal/bodycodegen"
)

func DecodeJointConstruction(raw []byte) (JointConstruction, error) {
	var result JointConstruction
	err := decode(raw, &result, 32<<20)
	return result, err
}

// ReplayJointComposition reconstructs every source combination and re-executes
// the consumed caller suite before executing a supplied evaluation suite. It
// neither loads a model nor treats consumed caller feedback as unseen data.
func ReplayJointComposition(ctx context.Context, filename string, source []byte, prior JointConstruction,
	cases CompositionCases, goBinary string) (JointEvaluation, error) {
	var result JointEvaluation
	if ctx == nil {
		return result, fmt.Errorf("joint replay requires context")
	}
	ctx, cancel := context.WithTimeout(ctx, 3*time.Minute)
	defer cancel()
	if err := verifyJointHeader(ctx, filename, source, prior); err != nil {
		return result, err
	}
	slots, space, err := jointSlots(ctx, filename, source, prior.Initial)
	if err != nil || space != prior.CandidateSpace {
		return result, fmt.Errorf("joint candidate space differs: %v", err)
	}
	kinds := jointCandidateKinds(slots)
	schema := jointObservationSchema(slots, prior.Attempts)
	if len(prior.FinalPathHoldouts) > 0 {
		schema = jointPathHoldoutSchema
	}
	if len(prior.FinalRecordHoldouts) > 0 {
		schema = jointRecordHoldoutSchema
	}
	if jointHasCriteria(prior) {
		schema = jointCriteriaSchema
	}
	if prior.Schema != schema || !slices.Equal(prior.CandidateKinds, kinds) {
		return result, fmt.Errorf("joint candidate kinds or schema differ")
	}
	order := jointMaskOrder(slots, prior.ProgramBudget)
	if len(prior.Attempts) == 0 || len(prior.Attempts) > len(order) {
		return result, fmt.Errorf("joint attempt count exceeds the bound")
	}
	executor := NewExecutor()
	defer executor.Close()
	result.ReplayFailure, err = verifyJointAttempts(ctx, filename, source, prior, slots, order, executor, goBinary)
	if err != nil {
		return result, err
	}
	result.ConstructionReplayed = true
	holdouts, err := evaluateJointPathHoldouts(ctx, filename, source, prior)
	if err != nil || compositionDigest(holdouts) != compositionDigest(prior.FinalPathHoldouts) {
		result.ConstructionReplayed = false
		return result, fmt.Errorf("final selected path holdouts or caller exposure differ: %v", err)
	}
	records, err := evaluateJointRecordHoldouts(ctx, filename, source, prior)
	if err != nil || !equalJointRecordHoldouts(records, prior.FinalRecordHoldouts) {
		result.ConstructionReplayed = false
		return result, fmt.Errorf("final selected record holdouts or caller exposure differ: %v", err)
	}
	criteria, err := evaluateJointCriteriaHoldouts(ctx, filename, source, prior)
	if err != nil || !equalJointCriteriaHoldouts(criteria, prior.FinalCriteriaHoldouts) {
		result.ConstructionReplayed = false
		return result, fmt.Errorf("final criteria holdouts or caller exposure differ: %v", err)
	}
	result.Runtime, err = evaluateJointInputs(ctx, filename, source, prior, cases, goBinary, executor)
	if err == nil {
		result.InputSeparation, err = measureJointInputs(ctx, filename, []byte(prior.SelectedSource), prior, cases)
	}
	return result, err
}

func verifyJointHeader(ctx context.Context, filename string, source []byte, r JointConstruction) error {
	if r.InputObservation != "" && r.InputObservation != jointInputObservation {
		return fmt.Errorf("joint input observation contract differs")
	}
	if r.Schema != jointSchema && r.Schema != jointMixedSchema && r.Schema != jointRejectionSchema && r.Schema != jointFillSchema && r.Schema != jointFillRejectionSchema && r.Schema != jointFaultSchema && r.Schema != jointPathSchema && r.Schema != jointPathHoldoutSchema && r.Schema != jointRecordHoldoutSchema && r.Schema != jointCriteriaSchema || r.Stage != "COMPLETE" || r.Failure != "" ||
		r.OriginalSourceSHA256 != digest(source) || r.ConstructionSHA256 != compositionDigest(r.ConstructionCases) ||
		r.ProgramBudget < 1 || r.ProgramBudget > 64 || r.SelectedAttempt < 0 || r.SelectedAttempt >= len(r.Attempts) {
		return fmt.Errorf("joint construction identity, stage or budget differs")
	}
	if err := validateJointSource(ctx, filename, source, r.ConstructionCases, r.Initial.Plan.EntryActivity); err != nil {
		return err
	}
	return VerifyComposition(ctx, filename, source, r.Initial)
}

func verifyJointAttempts(ctx context.Context, filename string, source []byte, prior JointConstruction,
	slots []jointSlot, order [][]uint16, executor *Executor, goBinary string) (*JointReplayFailure, error) {
	best := -1
	var bestSource []byte
	var bestProgram Composition
	calls, err := prepareJointCallContext(ctx, filename, source, prior)
	if err != nil {
		return nil, err
	}
	for i, recorded := range prior.Attempts {
		if !slices.Equal(recorded.Masks, order[i]) {
			return nil, fmt.Errorf("joint attempt %d differs from bounded source order", i)
		}
		attempt, selected, program, err := materializeJoint(ctx, filename, source, prior.ConstructionCases,
			prior.Initial.Plan.EntryActivity, slots, recorded.Masks)
		if err != nil {
			return nil, err
		}
		if !bodycodegen.EqualRecordCandidateHistory(recorded.Candidates, attempt.Candidates) ||
			!bodycodegen.EqualSearchCandidateHistory(recorded.SearchCandidates, attempt.SearchCandidates) ||
			!bodycodegen.EqualFillCandidateHistory(recorded.FillCandidates, attempt.FillCandidates) ||
			compositionDigest(attempt.PathCandidates) != compositionDigest(recorded.PathCandidates) ||
			compositionDigest(attempt.Rejection) != compositionDigest(recorded.Rejection) ||
			attempt.LocalPassed != recorded.LocalPassed || attempt.LocalTotal != recorded.LocalTotal ||
			attempt.CriteriaPassed != recorded.CriteriaPassed || attempt.CriteriaFailed != recorded.CriteriaFailed ||
			attempt.CriteriaUnknown != recorded.CriteriaUnknown || attempt.CriteriaTotal != recorded.CriteriaTotal {
			return nil, fmt.Errorf("joint attempt %d local obligations differ", i)
		}
		if attempt.Rejection != nil {
			if compositionDigest(recorded.Runtime) != compositionDigest(CompositionRuntime{}) {
				return nil, fmt.Errorf("joint rejected attempt %d cannot claim native caller observations", i)
			}
			continue
		}
		attempt.Runtime, err = executor.executeWithJointCalls(ctx, filename, selected, program, prior.ConstructionCases, goBinary, calls)
		if err != nil {
			return &JointReplayFailure{i, "CALLER_EXECUTION", attempt.Runtime}, fmt.Errorf("joint replay attempt %d: %w", i, err)
		}
		if !sameJointRuntime(attempt.Runtime, recorded.Runtime) {
			return &JointReplayFailure{i, "CALLER_COMPARISON", attempt.Runtime}, fmt.Errorf("joint attempt %d native caller observations differ", i)
		}
		if best < 0 || betterJoint(attempt, prior.Attempts[best]) {
			best, bestSource, bestProgram = i, selected, program
		}
		if jointComplete(attempt) && i != len(prior.Attempts)-1 {
			return nil, fmt.Errorf("joint construction continued after satisfying all obligations")
		}
	}
	if best != prior.SelectedAttempt || string(bestSource) != prior.SelectedSource ||
		bestProgram.Source != prior.Selected.Source || bestProgram.Driver != prior.Selected.Driver {
		return nil, fmt.Errorf("joint selected program differs from observed candidates")
	}
	decision, stop := jointOutcome(prior)
	if decision != prior.Decision || stop != prior.StopReason ||
		(decision != "COMPLETE_FINITE" && len(prior.Attempts) != len(order)) {
		return nil, fmt.Errorf("joint stopping observation differs")
	}
	return nil, VerifyComposition(ctx, filename, bestSource, prior.Selected)
}

func sameJointRuntime(a, b CompositionRuntime) bool {
	if !equalRetainedLocalSites(a.LocalSites, b.LocalSites) {
		return false
	}
	if a.CallContextSHA256 != b.CallContextSHA256 || a.ConstructionInputHistorySHA256 != b.ConstructionInputHistorySHA256 ||
		a.ObservedProjectionSHA256 != b.ObservedProjectionSHA256 || a.ObservedDriverSHA256 != b.ObservedDriverSHA256 {
		return false
	}
	if (hasCompositionFault(a) || hasCompositionFault(b)) &&
		(a.Schema != compositionFaultRuntimeSchema || b.Schema != compositionFaultRuntimeSchema) {
		return false
	}
	if b.Outcomes != nil || len(b.FaultSites) != 0 || hasCompositionFault(a) || hasCompositionFault(b) {
		if !completeArithmeticRuns(a) || !completeArithmeticRuns(b) || a.Runs[0].StdoutSHA256 != b.Runs[0].StdoutSHA256 ||
			compositionDigest(a.Outcomes) != compositionDigest(b.Outcomes) ||
			compositionDigest(a.FaultSites) != compositionDigest(b.FaultSites) ||
			a.ObservedProjectionSHA256 != b.ObservedProjectionSHA256 || a.ObservedDriverSHA256 != b.ObservedDriverSHA256 {
			return false
		}
	}
	semantic := func(r CompositionRuntime) any {
		// Scope is explanatory prose, like the runtime's own Scope. Counts,
		// statuses, reasons and source/history identities remain comparison inputs.
		r.InputSeparation.Scope = ""
		return []any{r.Stage, r.Failure, r.OriginalSourceSHA256, r.SelectedSourceSHA256,
			r.TypedPlanSHA256, r.GeneratedSHA256, r.DriverSHA256, r.RuntimeSuiteSHA256,
			r.FieldBindings, r.FieldSites, r.FieldUseSites, r.FieldProjectionSHA256, r.FieldObservation, r.BridgeObservation,
			comparableConditionSites(r), r.ConditionObservation, r.ReadSites, r.ReadInputs, r.ReadObservation, r.ConstructionSites, r.LocalUseSites, r.LocalObservation, r.Traces, r.FinitePassed, r.FiniteTotal, r.ModelCalls, r.ProjectionReplayed, r.RuntimeReplayed,
			r.InputSeparation}
	}
	return compositionDigest(semantic(a)) == compositionDigest(semantic(b))
}

func measureJointInputs(ctx context.Context, filename string, source []byte, prior JointConstruction,
	cases CompositionCases) (JointInputSeparation, error) {
	r := JointInputSeparation{Scope: "unique caller root-input tuples compared with consumed construction cases; local-example and model-training exposure are not established by this metric"}
	graph, err := prepareCompositionGraphForEntry(ctx, filename, source, prior.Initial.Plan.EntryActivity)
	if err != nil {
		return r, err
	}
	old, err := graph.inputRows(prior.ConstructionCases)
	if err != nil {
		return r, err
	}
	rows, err := graph.inputRows(cases)
	if err != nil {
		return r, err
	}
	consumed, seen := map[string]bool{}, map[string]bool{}
	for _, row := range old {
		consumed[compositionDigest(row)] = true
	}
	for _, row := range rows {
		key := compositionDigest(row)
		if seen[key] {
			r.DuplicateRows++
			continue
		}
		seen[key], r.UniqueInputs = true, r.UniqueInputs+1
		if consumed[key] {
			r.ConstructionInputs++
		} else {
			r.OtherInputs++
		}
	}
	return r, nil
}
