package extractor

import (
	"os"
	"testing"
)

func TestDerivedCandidateCapacity27401(t *testing.T) {
	root := os.Getenv("GOOO_FRESH_FIELD_ROOT")
	if root == "" {
		root = "../../../.."
	}
	targets := []string{"cmd/gooo#hasPackageOriginQueryOptions", "cmd/gooo#packageOriginQuery", "cmd/gooo#parsePackageExecuteArgs", "cmd/gooo#runBodyOrigins", "cmd/gooo#selectStarterFiles", "cmd/gooo#writeBodyDerivedCandidateOrigins", "cmd/gooo#writeBodyFillCandidateOrigins", "cmd/gooo#writeBodyFillOriginCandidates", "cmd/gooo#writePackageOriginInput", "internal/bodycodegen#InspectSourceFillCandidateOrigins", "internal/bodycodegen#InspectSourceFillDerivedOrigins", "internal/bodycodegen#InspectSourceFillOriginCandidates", "internal/bodycodegen#IsSourceFillDerivation", "internal/bodycodegen#SourceFillCandidateOriginInputs", "internal/bodycodegen#SourceFillDerivedOriginInputs", "internal/bodycodegen#sourceFillCandidateOriginRow", "internal/bodycodegen#sourceFillDerivedOriginRow", "internal/bodyexecution#NativeOriginQuery.hasSubjectSelection", "internal/bodyexecution#ValidateNativeOriginQuery", "internal/bodyexecution#nativeOriginPage.addField", "internal/bodyexecution#nativeOriginPage.fieldFileLocation", "internal/bodyexecution#nativeOriginPage.visitFields", "internal/bodyexecution#selectRecordedNativeOrigins", "internal/bodyexecution#validateOriginSubjectSelection", "internal/meta/languageassurance/verticalsliceclosureshadow#activeDenominatorChunk2", "internal/meta/languageassurance/verticalsliceclosureshadow#activeDenominatorDigestChunk2", "internal/meta/languageassurance/verticalsliceclosureshadow#decodeDenominator", "internal/meta/languageassurance/verticalsliceclosureshadow#expectedBoundarySpecsForVersion", "internal/meta/languageassurance/verticalsliceclosureshadow#validateDenominator", "internal/meta/languagereadiness/languagesyntax#expectedRegistry"}
	requireNamedCapacities(t, root, targets)
	t.Log("derived27401:all30 changed production declarations;prior17 retained plus grammar/list/registry/denominator changes;unchanged75-line rendered helper cap;producer/model0")
}
