module gooo-qualified-usage-independent

go 1.27.2

require github.com/knakk/rdf v0.0.0-20260907062454-42e760e83a4d
