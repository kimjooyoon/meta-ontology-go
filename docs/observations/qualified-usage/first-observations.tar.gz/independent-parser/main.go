package main

import (
 "encoding/json"
 "fmt"
 "os"
 "strings"

 "github.com/knakk/rdf"
)

type Input struct {
 Name string `json:"name"`
 WantedName string `json:"wanted_name"`
 Claim struct {
  Status string `json:"status"`
  Call string `json:"call_iri"`
  Value string `json:"value_iri"`
  Usage string `json:"usage_iri"`
  Lines []string `json:"lines"`
 } `json:"claim"`
}

func main() {
 data,err:=os.ReadFile(os.Args[1]);must(err)
 var inputs []Input;must(json.Unmarshal(data,&inputs))
 checked:=0
 for _,input:=range inputs {
  c:=input.Claim
  if c.Status!="RDF_READY" { if len(c.Lines)!=0||c.Call!=""||c.Value!=""||c.Usage!="" {panic(input.Name+": unresolved graph")};continue }
  triples,err:=rdf.NewTripleDecoder(strings.NewReader(strings.Join(c.Lines,"\n")+"\n"),rdf.NTriples).DecodeAll();must(err)
  if len(triples)!=26 {panic(fmt.Sprint(input.Name,": count ",len(triples)))}
  got:=map[string]bool{}
  for _,t:=range triples {
   if t.Subj.Type()!=rdf.TermIRI||t.Pred.Type()!=rdf.TermIRI {panic("expected absolute IRI nodes")}
   got[t.Subj.String()+"\x00"+t.Pred.String()+"\x00"+t.Obj.String()]=true
   if strings.Contains(t.Pred.String(),"hadRole")||strings.Contains(t.Pred.String(),"atTime")||strings.Contains(t.Pred.String(),"wasDerivedFrom") {panic("unobserved relation")}
  }
  prov:="http://www.w3.org/ns/prov#"
  for _,want:=range [][3]string{{c.Call,prov+"qualifiedUsage",c.Usage},{c.Usage,prov+"entity",c.Value},{c.Call,prov+"used",c.Value},{c.Value,prov+"wasGeneratedBy",c.Call}} {
   if !got[strings.Join(want[:],"\x00")] {panic("missing relation in "+input.Name)}
  }
  for _,want:=range [][2]string{{c.Call,"Activity"},{c.Value,"Entity"},{c.Usage,"Usage"}} {
   if !got[want[0]+"\x00http://www.w3.org/1999/02/22-rdf-syntax-ns#type\x00"+prov+want[1]] {panic("missing type")}
  }
  if input.WantedName!="" && !got[c.Value+"\x00urn:gooo:recorded-use:variableName\x00"+input.WantedName] {
   panic("decoded Unicode/control literal differs from original input")
  }
  checked++
 }
 must(json.NewEncoder(os.Stdout).Encode(map[string]any{"decision":"PASS","records":len(inputs),"parsed_graphs":checked,"triples_per_graph":26,"parser":"github.com/knakk/rdf@v0.0.0-20260907062454-42e760e83a4d","scope":"readonly independent RDF syntax/direction/type validation of saved first outputs; no native program replay"}))
}
func must(err error){if err!=nil {panic(err)}}
