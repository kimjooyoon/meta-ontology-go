package main

import (
	"encoding/json"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestRegisteredSelectionSplit11447(t *testing.T) {
	root := os.Getenv("GOOO_REGISTERED_SOURCE_ROOT")
	if root == "" {
		root = "../.."
	}
	raw, err := os.ReadFile(filepath.Join(root, "internal/meta/languageassurance/verticalsliceclosureshadow/evidence.go"))
	if err != nil {
		t.Fatal(err)
	}
	temporary := t.TempDir()
	if err := os.WriteFile(filepath.Join(temporary, "evidence.go"), raw, 0600); err != nil {
		t.Fatal(err)
	}
	plan, err := planSource(temporary, "evidence.go", 75)
	if err != nil {
		t.Fatal("registered selection cannot preserve source order", err)
	}
	maximum, functions := 0, 0
	for _, part := range plan.Parts {
		if physicalLines(part.Data) > 75 {
			t.Fatal("split part exceeds 75 lines", part.Subject)
		}
		set := token.NewFileSet()
		file, err := parser.ParseFile(set, part.Subject, part.Data, 0)
		if err != nil {
			t.Fatal(err)
		}
		for _, declaration := range file.Decls {
			function, ok := declaration.(*ast.FuncDecl)
			if !ok || !strings.HasPrefix(function.Name.Name, "activeDenominator") {
				continue
			}
			lines := set.Position(function.End()).Line - set.Position(function.Pos()).Line + 1
			maximum = max(maximum, lines)
			functions++
		}
	}
	if functions < 6 || maximum > 45 {
		t.Fatal("selection chunks were not bounded", functions, maximum)
	}
	if dir := os.Getenv("GOOO_SELECTION_OUTPUT"); dir != "" {
		value := map[string]any{"selection_functions": functions, "maximum_function_lines": maximum,
			"split_parts": len(plan.Parts), "line_limit": 75, "language_program_executions": 0}
		encoded, _ := json.MarshalIndent(value, "", "  ")
		if err := os.WriteFile(filepath.Join(dir, "selection11447.json"), encoded, 0600); err != nil {
			t.Fatal(err)
		}
	}
	t.Logf("registered selector functions=%d maximum=%d lines; actual splitter parts=%d each<=75; language executions0", functions, maximum, len(plan.Parts))
}
