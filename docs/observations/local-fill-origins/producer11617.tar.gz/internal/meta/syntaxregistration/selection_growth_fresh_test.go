package syntaxregistration

import (
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"

	"github.com/kimjooyoon/meta-ontology-go/internal/meta/languagereadiness/languagesyntax"
)

func TestSelectionChunkGrowth11617(t *testing.T) {
	root := os.Getenv("GOOO_REGISTERED_SOURCE_ROOT")
	if root == "" {
		root = "../../.."
	}
	path := closureRoot + "evidence.go"
	raw, err := os.ReadFile(filepath.Join(root, path))
	if err != nil {
		t.Fatal(err)
	}
	source, err := parseSourceUnits(map[string][]byte{path: raw}, closureRoot, "verticalsliceclosureshadow", false)
	if err != nil {
		t.Fatal(err)
	}
	version := 0
	for _, line := range strings.Split(string(raw), "\n") {
		if strings.HasPrefix(line, "var embeddedDenominatorV") {
			value, _ := strconv.Atoi(strings.Fields(strings.TrimPrefix(line, "var embeddedDenominatorV"))[0])
			version = max(version, value)
		}
	}
	source.activity = "gooo://selection-growth11617"
	if err := generateSelection(source, version+1, languagesyntax.FixedCapabilityTotal); err != nil {
		t.Fatal("owned chunks cannot accept another capability", err)
	}
	changes, err := source.finish()
	if err != nil {
		t.Fatal(err)
	}
	next, err := parseSourceUnits(changes, closureRoot, "verticalsliceclosureshadow", false)
	if err != nil {
		t.Fatal(err)
	}
	function, err := next.function("activeDenominator")
	if err != nil {
		t.Fatal(err)
	}
	entries, _, err := selectionEntries(next, function, "[]byte", "nil")
	if err != nil {
		t.Fatal("newly emitted chunk wrapper is not readable", err)
	}
	found := false
	for _, entry := range entries {
		if entry.capability == languagesyntax.FixedCapabilityTotal+1 {
			found = entry.result == evidenceName(version+1)
		}
	}
	if !found {
		t.Fatal("new capability lost its exact evidence symbol")
	}
	t.Logf("fresh selection-only continuation from v%d to v%d; exact new capability target preserved; language executions0", version, version+1)
}
