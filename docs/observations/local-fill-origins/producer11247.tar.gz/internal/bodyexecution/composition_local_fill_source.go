package bodyexecution

import "github.com/kimjooyoon/meta-ontology-go/internal/bodycodegen"

func compositionLocalFillOrigin(prior Composition, origin bodycodegen.BodyLocalOrigin) *bodycodegen.SourceFillLocalOrigin {
	for _, step := range prior.Steps {
		if fill := step.Generation.Report.BodyFill; fill != nil && fill.SourceOrigin != nil {
			if link := fill.SourceOrigin.LocalOrigin(origin); link != nil {
				return link
			}
		}
	}
	for _, preparation := range prior.Preparations {
		if fill := preparation.Generation.Report.BodyFill; fill != nil && fill.SourceOrigin != nil {
			if link := fill.SourceOrigin.LocalOrigin(origin); link != nil {
				return link
			}
		}
	}
	return nil
}
