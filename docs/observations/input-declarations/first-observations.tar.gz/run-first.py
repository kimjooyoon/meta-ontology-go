import pathlib,subprocess,time,json,sys,os
root=pathlib.Path('/private/tmp/gooo-input-declarations-20261015')
d=root/sys.argv[1];d.mkdir()
go='/Users/alice/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go'
args=[go]+sys.argv[2:]
start=time.monotonic();env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='go1.27.2',GOMAXPROCS='2')
with (d/'stdout').open('wb') as out,(d/'stderr').open('wb') as err:
 r=subprocess.run(args,cwd='/Users/alice/meta-go/meta-ontology-go',env=env,stdout=out,stderr=err)
m={'argv':args,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'scope':'first new declaration transport/source/input cohort'}
(d/'command.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(m));print((d/'stderr').read_text()[-1500:]);
if 'test' in args:print((d/'stdout').read_text()[-2500:])
sys.exit(r.returncode)
