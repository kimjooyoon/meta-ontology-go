import pathlib,json,copy
repo=pathlib.Path('/Users/alice/meta-go/meta-ontology-go');root=repo/'examples/source-control-reader'
(root/'input-positions.gooo.fixture').write_text('''package signaturepositions
namespace signaturepositions
entity Integer id "urn:gooo:type:integer"
# 두 입력은 타입이 같아도 서로 다른 자리에 선언되어 있다.
activity Difference(
    Integer,
    Integer
) -> Integer id "urn:signaturepositions:difference" computes `
return input0 - input1
`
''')
target='source/control:InspectInputs';cases=[];labels=[]
def row(n=2):
 return dict(schema='gooo/input-declaration-columns/v1',scope='activity_signature',source_sha256='sha256:'+'1'*64,activity_id='urn:signature:controlled-fixture',count=n,indices=list(range(n)),ports=['input'+str(i) for i in range(n)],type_names=['Integer']*n,type_ids=['urn:gooo:type:integer']*n,starts=[10*i for i in range(n)],ends=[10*i+7 for i in range(n)])
def add(label,r,reason='',pairs=0):
 labels.append(label)
 expected=dict(source_sha256=r['source_sha256'],activity_id=r['activity_id'],scope='activity_signature',status='INVALID_INPUT' if reason else ('SHARED_TYPE_DISTINCT_POSITIONS' if pairs else 'DECLARED_INPUTS'),reason=reason,inputs=0 if reason else r['count'],same_type_pairs=0 if reason else pairs)
 cases.append(dict(inputs={target:r},expected={target:expected}))
add('two equal types',row(),pairs=1)
add('three equal types',row(3),pairs=3)
r=row();r['type_names'][1]='Count';r['type_ids'][1]='urn:domain:count';add('distinct semantic types',r)
r=row();r['type_names'][1]='WholeNumber';add('display alias same type ID',r,pairs=1)
add('one input',row(1))
add('sixteen inputs boundary',row(16),pairs=120)
for label,key,value,reason in [
 ('missing type ID','type_ids',['urn:gooo:type:integer',''],'SIGNATURE_TYPE_ID_MISSING'),
 ('overlapping source ranges','starts',[0,6],'SIGNATURE_POSITION_INVALID'),
 ('repeated source index','indices',[0,0],'SIGNATURE_POSITION_INVALID'),
 ('repeated port','ports',['input','input'],'SIGNATURE_PORT_REPEATED'),
 ('missing column','ends',[7],'SIGNATURE_COLUMNS_MISMATCH'),
 ('wrong schema','schema','other','SOURCE_SCHEMA_MISMATCH'),
 ('missing activity','activity_id','','SOURCE_IDENTITY_MISSING'),
 ('negative first position','starts',[-1,10],'SIGNATURE_POSITION_INVALID'),
]:
 r=row();r[key]=value;add(label,r,reason)
add('seventeen inputs refused',row(17),'SIGNATURE_COLUMNS_MISMATCH')
add('zero inputs outside scope',row(0),'SIGNATURE_COLUMNS_MISMATCH')
(root/'input-cases.json').write_text(json.dumps(dict(schema='gooo/body-composition-cases/v1',cases=cases),ensure_ascii=False,indent=2)+'\n')
pathlib.Path('/private/tmp/gooo-input-declarations-20261015/case-labels.json').write_text(json.dumps(labels,indent=2)+'\n')
print('prepared',len(cases),'new cases')
