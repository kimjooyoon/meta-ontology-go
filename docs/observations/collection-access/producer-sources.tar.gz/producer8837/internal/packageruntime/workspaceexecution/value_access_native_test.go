package workspaceexecution

import (
	"bytes"
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/kimjooyoon/meta-ontology-go/internal/bodyexecution"
	"github.com/kimjooyoon/meta-ontology-go/internal/packageruntime"
)

func TestWorkspaceCollectionAccess8837(t *testing.T) {
	const source = `package readings
namespace access8837
entity Integer id "urn:gooo:type:integer"
entity Request id "urn:access8837:request" fields {
 field readings id "urn:access8837:request-readings" type integer required many
 field lower id "urn:access8837:lower" type integer required one
 field upper id "urn:access8837:upper" type integer required one
 field pick id "urn:access8837:request-pick" type integer required one
}
entity Window id "urn:access8837:window" fields {
 field readings id "urn:access8837:window-readings" type integer required many
 field pick id "urn:access8837:window-pick" type integer required one
}
activity TakeWindow(Request) -> Window id "urn:access8837:take" computes "let 시작 = input.lower; let 끝 = input.upper; return Window{readings: input.readings[시작:끝], pick: input.pick}"
activity At(Window) -> Integer id "urn:access8837:at" computes "if input.pick < 0 || input.pick >= int64(len(input.readings)) { return -1 }; return input.readings[__GOOO_BODY_HOLE_position__]" assembling {
 source_fill intent "선택한 구간에서 요청한 위치의 측정값을 읽는다" {
  hole "position"
  candidate "first8837" { fill "position" "0" }
  candidate "requested8837" { fill "position" "input.pick" }
 }
 value_case "[{\"readings\":[29,43,71],\"pick\":1}]" -> "43"
 value_case "[{\"readings\":[89,37],\"pick\":1}]" -> "37"
 holdout_value_case "[{\"readings\":[61,101,47],\"pick\":2}]" -> "47"
}
activity Read(Window) -> Integer id "urn:access8837:read" computes "return At(input)"
bind TakeWindow.result -> Read.input
`
	const cases = `{"schema":"gooo/body-composition-cases/v1","cases":[
 {"inputs":{"access8837:TakeWindow":{"readings":[151,157,163,167],"lower":1,"upper":4,"pick":1}},"expected":{"access8837:TakeWindow":{"readings":[157,163,167],"pick":1},"access8837:Read":163}},
 {"inputs":{"access8837:TakeWindow":{"readings":[173,179,181,191],"lower":0,"upper":3,"pick":0}},"expected":{"access8837:TakeWindow":{"readings":[173,179,181],"pick":0},"access8837:Read":173}},
 {"inputs":{"access8837:TakeWindow":{"readings":[-37,19,29,59,67],"lower":1,"upper":5,"pick":3}},"expected":{"access8837:TakeWindow":{"readings":[19,29,59,67],"pick":3},"access8837:Read":67}},
 {"inputs":{"access8837:TakeWindow":{"readings":[73,73,73],"lower":0,"upper":3,"pick":2}},"expected":{"access8837:TakeWindow":{"readings":[73,73,73],"pick":2},"access8837:Read":73}},
 {"inputs":{"access8837:TakeWindow":{"readings":[83,89,97],"lower":2,"upper":2,"pick":0}},"expected":{"access8837:TakeWindow":{"readings":[],"pick":0},"access8837:Read":-1}}
 ]}`
	suite, err := bodyexecution.DecodeCompositionCases([]byte(cases))
	if err != nil {
		t.Fatal(err)
	}
	manifest := packageruntime.Manifest{Schema: packageruntime.ManifestSchema,
		Entry: packageruntime.EntrySpec{PackagePath: "access8837", Activity: "Read"},
		Packages: []packageruntime.PackageSpec{{Path: "access8837", Name: "readings",
			Sources: []packageruntime.Source{{Filename: "측정구간.gooo", Content: source}}}},
	}
	result, err := ExecuteWorkspace(context.Background(), manifest, suite, "", "")
	if err != nil {
		t.Fatal("fresh collection source", err)
	}
	if result.Runtime.FinitePassed != 10 || result.Runtime.FiniteTotal != 10 || result.Runtime.ModelCalls != 0 {
		t.Fatal("five requests and ten activity outputs", result.Runtime)
	}
	before, _ := json.Marshal(result)
	flow, err := InspectSelectedValueOrigins(context.Background(), result, OriginQuery{Limit: 128})
	if err != nil || flow.Truncated {
		t.Fatal("source access inspection", err, flow)
	}
	facts := ProgramAccessFacts(flow)
	want := map[string]bool{"index_operand:input.pick": false, "slice_low:시작": false, "slice_high:끝": false,
		"slice_access:input.readings[시작:끝]": false, "index_access:input.readings[input.pick]": false}
	for _, fact := range facts {
		key := fact.Kind + ":" + fact.Expression
		if _, present := want[key]; present {
			want[key] = true
		}
		if fact.BodySHA256 == "" || fact.Start < 0 || fact.End <= fact.Start || fact.Truncated {
			t.Fatal("source access fact identity", fact)
		}
	}
	for key, found := range want {
		if !found {
			t.Fatal("missing access fact", key, facts)
		}
	}
	linked, original := false, false
	for _, row := range flow.Rows {
		vias := map[string]bool{}
		for _, step := range row.Path {
			vias[step.Via] = true
		}
		linked = linked || vias["call_return"] && vias["call_argument"] && vias["bind"]
		if row.CandidateID == "requested8837" {
			for _, location := range row.Locations {
				original = original || location.View == "workspace_input_file" && location.Filename == "측정구간.gooo" &&
					location.SourceSHA256 == sourceSHA256([]byte(source)) && strings.Contains(source[location.Start:location.End], "input.pick")
			}
		}
	}
	if !linked || !original {
		t.Fatal("call/bind path and selected index source", linked, original)
	}
	after, _ := json.Marshal(result)
	if !bytes.Equal(before, after) {
		t.Fatal("access query changed saved receipt")
	}
	if output := os.Getenv("GOOO_ACCESS_OUTPUT"); output != "" {
		raw, _ := json.MarshalIndent(map[string]any{"source": source, "manifest": manifest, "cases": json.RawMessage(cases),
			"result": result, "flow": flow, "access_facts": facts, "model_calls": 0}, "", "  ")
		if err := os.WriteFile(filepath.Join(output, "access8837.json"), raw, 0600); err != nil {
			t.Fatal(err)
		}
	}
	t.Logf("8837: native10/10 across5 requests, identical values and empty window included; access facts=%d; call/bind links and original selected index retained; receipt unchanged; model0", len(facts))
}
