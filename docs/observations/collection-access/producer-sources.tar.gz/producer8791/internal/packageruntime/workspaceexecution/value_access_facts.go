package workspaceexecution

// ProgramAccessFact exposes one source access occurrence in the returned paths.
// Ranges belong to the selected activity body identified by BodySHA256. A fact
// says where the source reads a field, index or slice; it is not a runtime read.
// Callers must retain the report's Analysis, Issues and Truncated fields.
type ProgramAccessFact struct {
	RootID     string `json:"root_id"`
	ActivityID string `json:"activity_id"`
	Kind       string `json:"kind"`
	Expression string `json:"expression"`
	BodySHA256 string `json:"body_sha256"`
	Start      int    `json:"start_byte"`
	End        int    `json:"end_byte"`
	Truncated  bool   `json:"snippet_truncated"`
}

// ProgramAccessFacts keeps the existing ProgramOriginFacts record unchanged.
// Repeated shortest paths can share a step; each root/step pair is emitted once.
func ProgramAccessFacts(report ProgramValueOrigins) []ProgramAccessFact {
	var out []ProgramAccessFact
	seen := map[string]bool{}
	for _, row := range report.Rows {
		for _, step := range row.Path {
			switch step.Kind {
			case "field_access", "index_access", "slice_access", "access_base",
				"index_operand", "slice_low", "slice_high", "slice_max":
			default:
				continue
			}
			key := row.RootID + "\x00" + step.ActivityID + "\x00" + step.NodeID
			if seen[key] {
				continue
			}
			seen[key] = true
			out = append(out, ProgramAccessFact{RootID: row.RootID, ActivityID: step.ActivityID,
				Kind: step.Kind, Expression: step.Expression, BodySHA256: step.BodySHA256,
				Start: step.Start, End: step.End, Truncated: step.SnippetsTruncated})
		}
	}
	return out
}
