package extractor

import (
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"testing"
)

func TestOriginReaderRenderedCapacity8161(t *testing.T) {
	root := os.Getenv("GOOO_ORIGIN_READER_SOURCE")
	if root == "" {
		root = filepath.Join("..", "..", "..", "bodycodegen")
	}
	methods, maximumFunction, maximumHelper := 0, 0, 0
	for _, name := range []string{"body_value_origin_statements.go", "body_value_origin_branches.go"} {
		source, err := os.ReadFile(filepath.Join(root, name))
		if err != nil {
			t.Fatal(err)
		}
		set := token.NewFileSet()
		file, err := parser.ParseFile(set, name, source, parser.ParseComments)
		if err != nil {
			t.Fatal(err)
		}
		selection, err := firstOversizedFunction(set, file, source)
		if err != nil {
			t.Fatal(err)
		}
		if selection.function != nil {
			t.Fatalf("%s requires unsupported method decomposition: %s", name, selection.function.Name.Name)
		}
		for _, observation := range selection.observations {
			methods++
			if observation.functionStatus != renderedCapacityWithinCap || observation.helperStatus != renderedCapacityWithinCap || observation.helperLines == nil {
				t.Fatalf("%s capacity not observed: %+v", name, observation)
			}
			maximumFunction = max(maximumFunction, observation.functionLines)
			maximumHelper = max(maximumHelper, *observation.helperLines)
		}
	}
	if methods != 7 {
		t.Fatalf("methods=%d", methods)
	}
	t.Logf("8161: seven origin-reader methods observed with the actual helper renderer; maximum function lines=%d/helper lines=%d; no source program execution", maximumFunction, maximumHelper)
}
