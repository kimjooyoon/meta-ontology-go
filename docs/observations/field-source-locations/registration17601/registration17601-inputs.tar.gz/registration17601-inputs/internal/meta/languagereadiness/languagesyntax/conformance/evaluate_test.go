package languagesyntax_test

import (
	"bytes"
	"encoding/json"
	"io/fs"
	"os"
	"strings"
	"testing"
	"testing/fstest"

	"github.com/kimjooyoon/meta-ontology-go/internal/meta/languageconcept"
	"github.com/kimjooyoon/meta-ontology-go/internal/meta/languagereadiness/languagesyntax"
)

const testHead = "0000000000000000000000000000000000000000"

const expectedInvalidCaseIDs = "unknown-keyword,unterminated-string,source-execution-invalid"

func fixture(t *testing.T) (fs.FS, []byte) {
	t.Helper()
	repository := os.DirFS("../../../../..")
	raw, err := fs.ReadFile(repository, "examples/language-syntax-roundtrip/corpus.json")
	if err != nil {
		t.Fatal(err)
	}
	return repository, raw
}

func TestCompleteCorpusProvesSyntaxRoundTrip(t *testing.T) {
	repository, raw := fixture(t)
	report := languagesyntax.Evaluate(repository, testHead, raw, languageconcept.BuildArtifact(repository))
	assertSourceInventory(t, repository, report.Source, report.Summary.GoooLines)
	if err := languagesyntax.Validate(report, testHead); err != nil {
		t.Fatal(err)
	}
	if report.Decision != languagesyntax.DecisionPass || report.Resolution != languagesyntax.ResolutionExact ||
		report.Summary.Satisfied != 101 || report.Summary.ValidCases != 98 ||
		report.Summary.InvalidCases != 3 || report.Summary.Unresolved != 0 ||
		report.Summary.CapabilitySatisfied != languagesyntax.FixedCapabilityTotal ||
		report.Summary.CapabilityTotal != languagesyntax.FixedCapabilityTotal ||
		report.Summary.CapabilityExecuted != languagesyntax.FixedCapabilityTotal ||
		report.Summary.CapabilityUnresolved != 0 ||
		report.Summary.GovernanceSatisfied != languagesyntax.FixedGovernanceTotal ||
		report.Summary.GovernanceTotal != languagesyntax.FixedGovernanceTotal ||
		report.Summary.GovernanceExecuted != languagesyntax.FixedGovernanceTotal ||
		report.Summary.GovernanceUnresolved != 0 ||
		report.Summary.ProjectionTotal != languagesyntax.FixedProjectionTotal || report.Summary.ProjectionSatisfied != languagesyntax.FixedProjectionTotal || report.Summary.ProjectionUnresolved != 0 ||
		len(report.Source.GoooFiles) != 119 || len(report.Source.PackageUnits) != 4 ||
		len(report.Source.PackageUnits[0].Members) != 2 || len(report.Source.PackageUnits[1].Members) != 3 ||
		len(report.Source.PackageUnits[2].Members) != 1 || len(report.Source.PackageUnits[3].Members) != 1 {
		invalidIDs := make([]string, 0, report.Summary.InvalidCases)
		for _, item := range report.Cases {
			if item.Definition.Kind == languagesyntax.KindInvalid {
				invalidIDs = append(invalidIDs, item.Definition.ID)
			}
		}
		t.Fatalf("report summary: decision=%q resolution=%q reason=%q gooo_lines=%d gooo_files=%d unregistered=%v missing=%v satisfied=%d valid=%d invalid=%d invalid_ids=%q expected_invalid_ids=%q unresolved=%d package_units=%d", report.Decision, report.Resolution, report.Reason, report.Summary.GoooLines, len(report.Source.GoooFiles), report.Source.UnregisteredGooo, report.Source.MissingRegistered, report.Summary.Satisfied, report.Summary.ValidCases, report.Summary.InvalidCases, strings.Join(invalidIDs, ","), expectedInvalidCaseIDs, report.Summary.Unresolved, len(report.Source.PackageUnits))
	}
	invalidIDs := make([]string, 0, report.Summary.InvalidCases)
	for _, item := range report.Cases {
		if item.Definition.Kind == languagesyntax.KindInvalid {
			invalidIDs = append(invalidIDs, item.Definition.ID)
		}
	}
	if strings.Join(invalidIDs, ",") != expectedInvalidCaseIDs {
		t.Fatalf("invalid corpus identities drifted: got=%q want=%q", strings.Join(invalidIDs, ","), expectedInvalidCaseIDs)
	}
}

func TestUnknownRegistryLowersResolution(t *testing.T) {
	repository, canonical := fixture(t)
	unknownField := bytes.Replace(canonical, []byte("{"), []byte(`{"unknown":true,`), 1)
	for _, raw := range [][]byte{[]byte(`{"schema":"UNKNOWN","cases":[]}`), unknownField} {
		report := languagesyntax.Evaluate(repository, testHead, raw, languageconcept.BuildArtifact(repository))
		if err := languagesyntax.Validate(report, testHead); err != nil {
			t.Fatal(err)
		}
		if report.Decision != languagesyntax.DecisionClosed || report.Resolution != languagesyntax.ResolutionLower ||
			report.Summary.Executed != 0 || report.Summary.Unresolved != 101 {
			t.Fatalf("unknown registry was not lowered: %#v", report)
		}
	}
}

func TestScopePartitionUsesFixedDenominatorsAndRejectsDrift(t *testing.T) {
	if languagesyntax.FixedTotal != 101 || languagesyntax.FixedCapabilityTotal != 99 ||
		languagesyntax.FixedGovernanceTotal != 2 ||
		languagesyntax.FixedCapabilityTotal+languagesyntax.FixedGovernanceTotal != languagesyntax.FixedTotal {
		t.Fatalf("scope denominators drifted: total=%d capability=%d governance=%d", languagesyntax.FixedTotal,
			languagesyntax.FixedCapabilityTotal, languagesyntax.FixedGovernanceTotal)
	}
	repository, canonical := fixture(t)
	cases := []struct {
		name string
		raw  []byte
	}{
		{"missing scope", bytes.Replace(canonical, []byte("      \"scope\": \"LANGUAGE_CAPABILITY\"\n"), nil, 1)},
		{"unknown scope", bytes.Replace(canonical, []byte(`"scope": "GOVERNANCE_OBSERVATION"`), []byte(`"scope": "UNKNOWN"`), 1)},
	}
	for _, testCase := range cases {
		t.Run(testCase.name, func(t *testing.T) {
			report := languagesyntax.Evaluate(repository, testHead, testCase.raw, languageconcept.BuildArtifact(repository))
			if report.Decision != languagesyntax.DecisionClosed || report.Resolution != languagesyntax.ResolutionLower ||
				report.Summary.Unresolved != languagesyntax.FixedTotal {
				t.Fatalf("scope drift was not rejected: %#v", report)
			}
		})
	}
}

func TestRecordBindingRetainsEverySyntaxReplayObligation(t *testing.T) {
	repository, raw := fixture(t)
	report := languagesyntax.Evaluate(repository, testHead, raw, languageconcept.BuildArtifact(repository))
	found := 0
	for _, item := range report.Cases {
		if item.Definition.ID != "language-record-binding" {
			continue
		}
		found++
		if item.Definition.Path != "examples/language-record-binding/main.gooo" ||
			!item.Definition.EntityFields || item.Definition.Scope != languagesyntax.ScopeLanguageCapability ||
			item.Definition.Kind != languagesyntax.KindValid || item.Status != "SATISFIED" ||
			!item.Evidence.ASTReplayed || !item.Evidence.ByteReplayed || !item.Evidence.SemanticReplayed ||
			!item.Evidence.GetPut || !item.Evidence.PutGet {
			t.Fatalf("record syntax obligations not closed: %#v", item)
		}
	}
	if found != 1 {
		t.Fatalf("record syntax case count=%d want=1", found)
	}
}

func TestRemovingRecordBindingCannotLowerCorpusDenominator(t *testing.T) {
	repository, raw := fixture(t)
	var registry languagesyntax.Registry
	if err := json.Unmarshal(raw, &registry); err != nil {
		t.Fatal(err)
	}
	removed := 0
	for index, item := range registry.Cases {
		if item.ID == "language-record-binding" {
			registry.Cases = append(registry.Cases[:index], registry.Cases[index+1:]...)
			removed++
			break
		}
	}
	if removed != 1 {
		t.Fatal("record case missing from canonical fixture")
	}
	mutated, err := json.Marshal(registry)
	if err != nil {
		t.Fatal(err)
	}
	report := languagesyntax.Evaluate(repository, testHead, mutated, languageconcept.BuildArtifact(repository))
	if report.Decision != languagesyntax.DecisionClosed || report.Resolution != languagesyntax.ResolutionLower ||
		report.Summary.Total != 101 || report.Summary.Executed != 0 || report.Summary.Unresolved != 101 {
		t.Fatalf("removing a case reduced proof obligations: %#v", report.Summary)
	}
}

type projectionOverlay struct {
	fs.FS
	path string
	data []byte
}

func (o projectionOverlay) Open(name string) (fs.File, error) {
	if name != o.path {
		return o.FS.Open(name)
	}
	if o.data == nil {
		return nil, fs.ErrNotExist
	}
	return fstest.MapFS{name: &fstest.MapFile{Data: o.data}}.Open(name)
}

func TestProjectionCorpusBindsActualSourceAndBothArtifacts(t *testing.T) {
	repository, raw := fixture(t)
	baseline := languagesyntax.Evaluate(repository, testHead, raw, languageconcept.BuildArtifact(repository))
	if baseline.Decision != languagesyntax.DecisionPass || len(baseline.ProjectionUnits) != languagesyntax.FixedProjectionTotal {
		t.Fatalf("projection corpus not proven: %s %v", baseline.Decision, baseline.ProjectionUnits)
	}
	if baseline.Summary.GetPutLaws != baseline.Summary.ValidCases || baseline.Summary.PutGetLaws != baseline.Summary.ValidCases {
		t.Fatal("structure profile changed the existing general BX law denominator")
	}
	for _, sample := range []struct {
		name, path, old, replacement string
		missing                      bool
	}{
		{"changed-source-type", "internal/completeness/receipt.gooo", "type Count required one", "type Text required one", false},
		{"changed-generated-go", "internal/completeness/receipt.generated.go", "Numerator   int", "Numerator   string", false},
		{"changed-json-schema", "internal/completeness/receipt.schema.json", "\"minimum\": 0", "\"minimum\": -1", false},
		{"missing-generated-go", "internal/completeness/receipt.generated.go", "", "", true},
		{"missing-json-schema", "internal/completeness/receipt.schema.json", "", "", true},
		{"changed-delta-source", "internal/completenessdelta/delta.gooo", "type Count required one", "type Text required one", false},
		{"changed-delta-go", "internal/completenessdelta/delta.generated.go", "Numerator   int", "Numerator   string", false},
		{"changed-delta-schema", "internal/completenessdelta/delta.schema.json", "\"minimum\": 0", "\"minimum\": -1", false},
		{"missing-delta-go", "internal/completenessdelta/delta.generated.go", "", "", true},
		{"changed-outcome-source", "internal/outcomedelta/delta.gooo", "type Text required one", "type Record required one", false},
		{"changed-outcome-go", "internal/outcomedelta/delta.generated.go", "ActivityID        string", "ActivityID        int", false},
		{"changed-outcome-schema", "internal/outcomedelta/delta.schema.json", "\"type\": \"string\"", "\"type\": \"integer\"", false},
		{"missing-outcome-go", "internal/outcomedelta/delta.generated.go", "", "", true},
		{"missing-outcome-schema", "internal/outcomedelta/delta.schema.json", "", "", true},
	} {
		t.Run(sample.name, func(t *testing.T) {
			var altered []byte
			if !sample.missing {
				original, err := fs.ReadFile(repository, sample.path)
				if err != nil {
					t.Fatal(err)
				}
				altered = bytes.Replace(original, []byte(sample.old), []byte(sample.replacement), 1)
				if bytes.Equal(altered, original) {
					t.Fatal("counterexample did not alter the actual input")
				}
			}
			overlay := projectionOverlay{repository, sample.path, altered}
			report := languagesyntax.Evaluate(overlay, testHead, raw, languageconcept.BuildArtifact(overlay))
			if err := languagesyntax.Validate(report, testHead); err != nil {
				t.Fatal(err)
			}
			if report.Decision != languagesyntax.DecisionClosed || report.Summary.ProjectionSatisfied != languagesyntax.FixedProjectionTotal-1 ||
				report.Summary.ProjectionTotal != languagesyntax.FixedProjectionTotal || report.Summary.Satisfied != 101 {
				t.Fatalf("projection failure was hidden or changed ordinary case coverage: %#v", report.Summary)
			}
			if sample.missing && (report.Resolution != languagesyntax.ResolutionLower || report.Summary.ProjectionUnresolved != 1) {
				t.Fatal("missing artifact was not preserved as unresolved")
			}
		})
	}
	baseline.ProjectionUnits = nil
	if languagesyntax.Validate(baseline, testHead) == nil {
		t.Fatal("consumer accepted an omitted projection obligation")
	}
}

func TestProjectionRegistryCannotDropOrRedirectObligations(t *testing.T) {
	repository, raw := fixture(t)
	for _, mutate := range []func(*languagesyntax.Registry){
		func(r *languagesyntax.Registry) { r.ProjectionUnits = nil },
		func(r *languagesyntax.Registry) { r.ProjectionUnits = r.ProjectionUnits[:2] },
		func(r *languagesyntax.Registry) { r.ProjectionUnits[0].Profile = "invented/profile" },
		func(r *languagesyntax.Registry) { r.ProjectionUnits[0].GoPath = "unrelated.go" },
	} {
		var registry languagesyntax.Registry
		if err := json.Unmarshal(raw, &registry); err != nil {
			t.Fatal(err)
		}
		mutate(&registry)
		changed, err := json.Marshal(registry)
		if err != nil {
			t.Fatal(err)
		}
		report := languagesyntax.Evaluate(repository, testHead, changed, languageconcept.BuildArtifact(repository))
		if err := languagesyntax.Validate(report, testHead); err != nil {
			t.Fatal(err)
		}
		if report.Decision != languagesyntax.DecisionClosed || report.Summary.Unresolved != 101 ||
			report.Summary.ProjectionUnresolved != languagesyntax.FixedProjectionTotal || report.Summary.ProjectionTotal != languagesyntax.FixedProjectionTotal {
			t.Fatal("registry drift reduced the fixed proof obligations")
		}
	}
}
