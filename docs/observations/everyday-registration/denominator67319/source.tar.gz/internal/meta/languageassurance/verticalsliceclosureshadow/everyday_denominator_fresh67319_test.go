package verticalsliceclosureshadow

import (
	"bytes"
	"reflect"
	"testing"
)

func TestEverydayDenominator73RetainsHistorical72Target67319(t *testing.T) {
	current, err := decodeDenominator(activeDenominator())
	if err != nil || current.Version != 73 || current.Boundaries[0].Target != 109 ||
		activeDenominatorDigest() != DenominatorMigrationV73Digest {
		t.Fatal("current registered-source target", current, err)
	}
	previous, err := decodeDenominator(embeddedDenominatorV72)
	if err != nil || previous.Version != 72 || previous.Boundaries[0].Target != 108 ||
		digestBytes(embeddedDenominatorV72) != DenominatorMigrationV72Digest {
		t.Fatal("historical source target changed", previous, err)
	}
	if !reflect.DeepEqual(previous.Boundaries[1:], current.Boundaries[1:]) {
		t.Fatal("unrelated boundaries or links changed")
	}
	lowered := bytes.Replace(activeDenominator(), []byte("\"target\": 109"), []byte("\"target\": 108"), 1)
	if bytes.Equal(lowered, activeDenominator()) {
		t.Fatal("counterexample did not change its source")
	}
	if _, err := decodeDenominator(lowered); err == nil {
		t.Fatal("unapproved current target accepted")
	}
}
