package extractor

import (
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"testing"
)

func TestLengthIntegerCapacity20631(t *testing.T) {
	root := os.Getenv("GOOO_FRESH_FIELD_ROOT")
	if root == "" {
		root = "../../../.."
	}
	paths := []string{"length_integer_context.go", "length_integer_bindings.go", "length_integer_visit.go", "length_integer_arguments.go", "length_integer_promote.go", "bodycodegen.go", "record_flow_expressions.go"}
	methods := 0
	for _, path := range paths {
		path = filepath.Join("internal", "bodycodegen", path)
		source, err := os.ReadFile(filepath.Join(root, path))
		if err != nil {
			t.Fatal(err)
		}
		set := token.NewFileSet()
		file, err := parser.ParseFile(set, path, source, 0)
		if err != nil {
			t.Fatal(err)
		}
		for _, declaration := range file.Decls {
			fn, ok := declaration.(*ast.FuncDecl)
			if !ok || (filepath.Base(path) == "bodycodegen.go" && fn.Name.Name != "normalizeIntegerLocalInitializers") ||
				(filepath.Base(path) == "record_flow_expressions.go" && fn.Name.Name != "expression") {
				continue
			}
			result := observeRenderedCapacity(set, file, source, fn)
			if result.functionStatus != renderedCapacityWithinCap || result.helperStatus != renderedCapacityWithinCap || result.helperLines == nil {
				t.Fatalf("%s %s: %+v", path, fn.Name.Name, result)
			}
			methods++
			t.Log(path, fn.Name.Name, "rendered", *result.helperLines)
		}
	}
	if methods != 9 {
		t.Fatal("changed production function population", methods)
	}
	t.Log("new length-context source functions;actual generated helper capacity within unchanged75-line cap;producer/model0")
}
