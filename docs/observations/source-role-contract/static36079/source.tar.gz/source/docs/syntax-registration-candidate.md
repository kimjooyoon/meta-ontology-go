# Source-bound syntax registration candidate

This is the candidate-generation backend for issue #742, not admission of a
fifth operation into the existing automatic meta-operation planner.

The embedded Gooo contract declares an execution-identity pinning activity,
RegisterSyntaxCapability and nine artifact activities. Native lowering binds their Used/WasGeneratedBy relations and carries
the source digest, semantic digest, activity IDs, exact input digest and explicit
typed request into a complete candidate. No request parameter is hidden in a
subject name or inferred from prose.

## Exact first operation

The input source already exists in the caller snapshot. The request declares a
VALID LANGUAGE_CAPABILITY case, its source path, entity-fields or implicit-port
support, proof choice, current denominator version, input/source digests and Go
runtime version and execution_identity. The identity includes SHA-256 digests of
the running generator, the selected Go driver and its compiler, plus Go version,
OS and architecture. The source must satisfy the existing five syntax/BX obligations.
A missing input is UNKNOWN/DIRECT_MISSING; changed content or runtime identity is
UNKNOWN/STALE. Both retain stage, step, reason, unknown_class, next_operation and
blocked_by. Duplicate case IDs or paths are REFUTED.

Generation coordinates exactly nine semantic artifact roles: corpus JSON, native registry,
syntax counters, syntax conformance expectations, denominator admission,
denominator selection, digest pin, one new denominator JSON, and migration tests.
The canonical ordinary registration writes exactly nine physical member files.
A canonical meta-source promotion writes ten: its case literal and MetaSources
list have distinct source owners. The nine semantic artifact roles are unchanged.
After repository projection, one role can own several physical files and a file
can participate in several roles. All nine activity/output bindings remain
mandatory; emitted/required physical members are the complete distinct write set,
not a substituted language-completeness score.

Native symbols are resolved across the declared package namespaces. Every Go
source unit in those namespaces is included in the input snapshot; missing,
duplicated or newly added units cannot silently inherit prior evidence.
AST token-file ownership binds edits to actual paths, ignoring misleading
line-directive aliases. `artifacts` carries nine lowered activity/output IDs and
their member paths; each member carries all generating `activity_ids`.
Go changes are bounded AST-position edits. Existing denominator files are
immutable inputs; only the new version is emitted. Current obligations increase
by one and unrelated boundary/link targets are preserved.

The operation emits PROPOSAL_ONLY / UNASSESSED, never apply or promotion
permission. Missing, duplicated, altered or historical-path candidate members
fail candidate validation. Replay equality alone is not semantic acceptance.

## Caller path

Use the implemented experimental entry point:

~~~sh
go run ./cmd/syntax-registration-candidate -root PROJECT -request request.json -inspect
go run ./cmd/syntax-registration-candidate -root PROJECT -request request.json -output NEW_EXTERNAL_DIRECTORY
~~~

The first command reports observed snapshot/source digests, Go runtime version
and execution_identity. Pin all of them explicitly in the request before generation.
The Go driver is observed with GOTOOLCHAIN=local and GOWORK=off, as in native
evaluation. Observation invokes only go env and reads executable bytes; it does
not build, test, install, repair or grant authority. No absolute tool path is
serialized into the identity. The second writes
the complete member files, candidate.json and execution.json outside the input project.
Existing output directories and parents resolving inside the input are rejected.
It does not apply the candidate to the project.

Request example, with observed values filled by the caller:

~~~json
{
  "case": {
    "id": "my-new-capability",
    "path": "examples/my-new-capability/main.gooo",
    "kind": "VALID",
    "expected_decision": "PASS",
    "proof_choice": "COHERENCE",
    "meta_operation": "replay-language-syntax",
    "scope": "LANGUAGE_CAPABILITY",
    "entity_fields": true
  },
  "base_version": 30,
  "snapshot_digest": "sha256:<observed-snapshot>",
  "source_digest": "sha256:<observed-source>",
  "toolchain": "go1.27.2",
  "execution_identity": {
    "go_version": "go1.27.2",
    "goos": "linux",
    "goarch": "amd64",
    "executable_sha256": "sha256:<observed-generator>",
    "go_command_sha256": "sha256:<observed-go-driver>",
    "compiler_sha256": "sha256:<observed-compiler>"
  }
}
~~~

## Internal meta source registration

An explicit request may also name an existing `internal/meta/**/*.gooo`
source. This is the same VALID LANGUAGE_CAPABILITY registration operation,
not a meta-source exemption or a smaller denominator. Lexical traversal,
absolute paths, look-alike prefixes, other internal namespaces and non-Gooo
extensions remain rejected before input observation. This path predicate is
not a filesystem sandbox or write permission.

The source is read-only input. All nine generated artifact roles remain
mandatory, the next denominator version is appended, historical versions
remain unchanged, and candidate application/promotion authority stays false.
Source, snapshot, typed request and executable identities remain pinned.

The existing dedicated Actions workflow now exercises both the original
example source and a policy-revision-shaped internal meta source. Each uses
an isolated CI copy, exact candidate reconstruction, deterministic replay
and the unchanged syntax/vertical-slice conformance packages. Internal-source
evidence is kept under `internal-meta-source/` alongside the original
case's artifacts. Both retain the exact request and Gooo source in addition
to the candidate, native report and command output.

The internal case is a declared synthetic compiler regression, not external
adoption or proof of policy revision execution. Case-specific wall time is
an observation only; no speed or memory improvement is claimed without a
matched before/after pair. No extra local build, test, formatter or generator
execution is part of this workflow.

## Explicit promotion of an existing meta source

Set `"promote_meta_source": true` in the typed request to move exactly one
already registered meta source into the executed LANGUAGE_CAPABILITY corpus.
The request must name a source present exactly once in `meta_sources`, not
an existing executed case or package member. Omission or false preserves the
original unregistered-source behavior and cannot authorize this promotion.

The native operation removes that one membership from both corpus and native
registry while adding the exact requested case. The same nine artifact roles
also increase syntax counters, conformance expectations and the next
denominator version. Other cases, other meta sources, package units, source
bytes and denominator history remain unchanged. An incomplete or resealed
candidate is rejected by full reconstruction; matching file counts alone is
not acceptance.

The explicit flag is included in the canonical request digest. It is not
inferred from a path, title, score or failed check and does not grant apply,
merge, release or planner-admission authority.

The Actions-only `registered-meta-source/` case promotes the compiler's
existing `internal/meta/syntaxregistration/contract.gooo` without overwriting
that source even in the temporary snapshot. It retains the exact request,
source, complete generated candidate and unchanged conformance output.
The original example and previously unregistered internal-source cases remain
separate. These are synthetic compiler regressions, not external utility.

## Native evidence and remaining integration

The dedicated Actions job retains the canonical nine-file ordinary registration
and ten-file meta-source promotion end-to-end cases.
The repository-projection job additionally uses its actual authorized transformed
workspace, copies it with source links dereferenced, generates the complete
candidate twice, applies every member only to that CI temporary copy, and runs
the existing syntax and vertical-slice conformance tests. It neither substitutes
a historical checkout for the projected case nor skips the original full-module
test. Arbitrary source-file relocation, ambiguous symbol owners, added source
units and forged source locations have separate regression cases. It reports the actual emitted/required members,
replay comparison, native command result and elapsed milliseconds. Zero manual
follow-up edits is reported only after those unchanged conformance commands pass.
No local test, build or formatter execution is part of this development workflow.

The dedicated candidate witness does not assess common-planner or dispatch
admission. Its `global_planner_admission` observation is `UNASSESSED`; it does
not claim those integrations are absent or certified. The separate native
common-execution checks own that evidence.
The syntax.register:v2 contract routes every generation activity through
PinnedRegistrationInput, produced by PinRegistrationExecutionIdentity. Compilation
and generation both reobserve and compare execution identity. Missing identity
is UNKNOWN/DIRECT_MISSING, changed bytes are UNKNOWN/STALE, and malformed digests
are REFUTED. All six UNKNOWN fields remain present. Candidate execution_binding
carries the lowered pin activity and input/output IDs together with the observed
identity. Candidate validation rejects a substituted identity.

This pins three executable identities, not the entire environment, toolchain
publisher authenticity or semantic correctness. The new identity requirement is
an explicit experimental request-ABI change: version-only requests are no longer
accepted. Native reports carry the actual binding; existing nine-role and
canonical/projected conformance obligations remain bound to the complete write set.
Issue #742 remains open until those input/identity/executor integrations and all
six original acceptance obligations are supported by exact-head native evidence.
Neither candidate byte equality nor the backend tests close product utility or
the entire language's self-improvement goal.

## Registry helpers and declaration origins

The native `Cases` field may hold a direct case-slice literal or a local
zero-argument helper. A helper may return another such helper or assemble a
sequence using one local declaration, ordered `append(sequence, helper()...)`
assignments, and a final return. Each reachable helper and literal has one use.
The final literal owns the insertion; earlier groups and unrelated literals
retain their bytes. Inline literal punctuation and real token-file paths are
preserved, including source units carrying line directives.

Branches, cycles, repeated helper paths, external calls, arguments, named return
bindings and shadowed append/helper bindings remain unresolved. Generation
returns no candidate for those shapes. This is a finite source observation used
by the Gooo `GenerateNativeRegistry` activity. It does not evaluate arbitrary
Go or use a model to invent registry members.

The [recorded source cohorts](observations/registry-source-origins/README.md)
include the failed inline punctuation case and its changed-source successor.
Full native canonical/projected acceptance belongs to the submitted head's own
original Actions runs.

## Historical targets during continued generation

Generating the next corpus version pins the previous syntax target as an
explicit source case before the current capability count grows. Historical
migration checks compare their own immutable evidence, while current checks
follow the selected source version. This keeps a v72 observation at108 when
v73/v74 use109/110. Original source-case membership, the other five boundaries
and all thirteen link obligations are preserved.

[Recorded continuation](observations/refactor-type-origins/README.md) contains
actual compiled two-step decoder observations and the standard-type reader
lifetime used by Gooo function decomposition.
