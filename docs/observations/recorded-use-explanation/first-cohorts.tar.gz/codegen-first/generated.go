package recordeduse

//gooo:generated:start id="urn:gooo:recorded-use:columns" kind="entity"
type GoooRecord76b42d5002c15b91565ba15fc336e8a729fc8b2a584cb1b69642ffe7c6160539 struct {
	GoooFielde54f16594be5da52be09d5dfeac22429e9565ba3950f9ed21dfe439f19a10779 string   `json:"receipt_sha256"`
	GoooField05b6775902feb9dce9def1b7a950ceac973825e48852cb7b94520ea57582020a string   `json:"source_sha256"`
	GoooField5ce85dd712d551ff89fb90b7e83184ba7dc6b9cfc95469029d8af088d141a251 string   `json:"journal_sha256"`
	GoooField9f70e7895605c6d69656e699b5fab8b367893f4186bd70976a77a1932527b42c int64    `json:"offset"`
	GoooField0ff1b2773efaed4ac30768d497869a8bf20fcf00533a548c4a73baa49fc6100a int64    `json:"total_rows"`
	GoooField796e84a119ba1aab5120374a13b9bf8335f18357fff864fb29b467261b8a7bf8 int64    `json:"frames_dropped"`
	GoooFielddced1c23b00564ae40804f7062814b577a8f1481b8e933d9b31461960ef5c2f5 int64    `json:"writes_dropped"`
	GoooField13f6da2ee6b7d6fdbb216a69f6c75aa321e5f84e972ab6933beb10c9c3f34320 int64    `json:"uses_dropped"`
	GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4 []int64  `json:"cases"`
	GoooField9ce805e12017518a03dcd54fe36ebc08ffe82594dec60694f889261de9f8c924 []int64  `json:"use_indices"`
	GoooField245010b77888ef2f88c943698af6858be8aa6d5ff1746610e3efd383b839392a []int64  `json:"frames"`
	GoooField16ff0d90fd42acc7897f1da6fe4eb25511202a330e109f46e9b9193596bdd223 []int64  `json:"assignments"`
	GoooField4ad5c2f3fbd8b996d10dd2582b6df3257f4f8443754fd81a1b4154b48c957877 []string `json:"roots"`
	GoooField5923dd6d3182deb6aa2ddeb89c2351df5c9880f5c29b7cc810d113a6598dd633 []string `json:"activities"`
	GoooFieldbaf2fdc95f656a6293b82956b1a858c0a78a1c6b449ef0dfe4c35a0633ad626f []bool   `json:"resolved"`
	GoooField9b7741b93c335f1a42721aef3b1bb87518119e80ed06ebf0c0c5d1357edada8e []string `json:"reasons"`
	GoooFieldb5ef0743355cccdeb0b253aa22a7357fd16cb61af335a0ca1559565b13f3bee5 []int64  `json:"version_frames"`
	GoooField0f2deb0c3105e58e37e25da0a88a69337af46ef2828f255d838bc154f3ec3079 []string `json:"version_activities"`
	GoooField4376cfdedcebf007d2669d19e40b85204ffed3ec86f0d66e01623edfae1e1f4c []bool   `json:"version_completed"`
	GoooFieldcbe3e8a02997fc1ca1c482cd9b5a89ae8acd58ebd18e63b69278741bccdd694f []string `json:"read_sha256"`
	GoooFieldf573594c0dc321d5cd0fd365dc20947049dfb992e255d8428c019acd8564b8da []int64  `json:"read_starts"`
	GoooFieldd60f008f172fff5d266d76d4feb368f9f37724780a87e3ecfa8a3a2fe1d33861 []int64  `json:"read_ends"`
	GoooField1e619c42c3debfddc974efd3723078ffe7dc3007a05ed4f4c2a9e5ce8c5e2c04 []string `json:"read_mappings"`
	GoooField8ff92740d6a0ec2b5ac9c4719a27a0b1b40d0be2fb59606c3d9a999f44280efd []string `json:"names"`
	GoooField493ba281a7a1ecc5330c0ab7d1a00f35f9224e83ed33b2352bc3db4893a8ba39 []int64  `json:"ordinals"`
	GoooField817b021f2ce4cbdc3624db8342ec2b75c91cb391510e3d6e43e630520a7b4750 []string `json:"scalar_types"`
}

//gooo:generated:end id="urn:gooo:recorded-use:columns" kind="entity"
//gooo:generated:start id="urn:gooo:recorded-use:usageclaim" kind="entity"
type GoooRecord6a094015dd891a5e0d6ca6894f4b55220141059d5334eaa7dbf50aec90b903a8 struct {
	GoooField23f68dfebcdf28a57bcc8a8c75044cf6d621c8172573f0011b00395075469afc string `json:"receipt_sha256"`
	GoooField6856f212c0ccd02675ec4adf896335151c9f3af2ff9905721a1e90742b22c174 string `json:"source_sha256"`
	GoooFieldf700233d2b41e1222aacb1e0c0c567c702481436580b9be82b834bdc41410c86 string `json:"journal_sha256"`
	GoooFieldadfeb8685a0470bfb5dc3b7bfce2ba50905c995652f2ffe07092edbf01150233 string `json:"receipt_scope"`
	GoooField46cebd890d285765182b716d7a9aedd4a65fba981c9d739b5a5545c030f17eb2 string `json:"generation_relation_iri"`
	GoooFieldc8b4e1f00bfab81d831fc73ccf9222454d0f9a8044c65e2cc2ae069f1ca4c385 string `json:"use_relation_iri"`
	GoooFieldaf5ece6d06cb08fa047caf8ad7308e63b7744584b9f72e1ced45182e9743cb9a int64  `json:"case_index"`
	GoooFielde780cbb25d697508723dfe3bf9b9dd9105eea802781571aa9442c2d1e89a5766 int64  `json:"use_index"`
	GoooFielde4a11cb83a1d7c75da5aaf28dee4f368cb2c68413048316661496def2ec5a544 int64  `json:"frame"`
	GoooField65142565ed946340e600a2b8c376b24978561a092b7783c1ed43af9490e612c9 int64  `json:"assignment_index"`
	GoooField7a2d185f61a292306f857e834009d18fd6db0654a5716a504144533b5c0cdd5c string `json:"root_activity_id"`
	GoooField0efc673341596d46a66c35d899a7c37a7d7620bcba0e0d494168fc0bdb7390f1 string `json:"activity_id"`
	GoooField29e81268ce7284c43279bf9ce1d39bd0e84bc7a85c0d4fc11da02e28e44b2f52 int64  `json:"version_frame"`
	GoooField69fe4f763338cac4b46633c3a1c8ac8dd6a295cce320bb08177914e83f2b7afe string `json:"version_activity_id"`
	GoooFielde6d52acadc1e7d799453fb2b7d1ae37caa2470fd16a3789728294ffa8c2cb44a string `json:"variable_name"`
	GoooField4c68fad4c98034af94a83c4ff75929a3597b70bb59b64e0aec709234c8668aef int64  `json:"variable_ordinal"`
	GoooFieldf331747d0651949f99fbe69b431174b61323f53f69240baebcefb8ab6e4b27e8 string `json:"scalar_type"`
	GoooField62542dba55208cb65f415abdd266ba02912062f61c94ae80f16216eb236b120e string `json:"read_sha256"`
	GoooField274b01ced899f84b352923f121df1f40c6544b42b4693e1ac199373c11af3aef int64  `json:"read_start"`
	GoooFieldab9d5d408fe59773829d194269b8100d2feec445c258f2a1fdc89801b63b5fc0 int64  `json:"read_end"`
	GoooFieldc54d4a523b64dbe234b119bedd248c3f27cf8db5f7ebb6d9cfaee98abc51459e string `json:"read_mapping"`
	GoooFielde04af8c1c8cef09350e83349c1e97ed990e02baa00e721bab3c0e203e5fcf273 bool   `json:"local_records_dropped"`
	GoooField8eac8495791d8947a1ed9c5ce7e20ed669fefe05bbb423f8cc62998b21aa4ae7 string `json:"reason"`
	GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 string `json:"status"`
}

//gooo:generated:end id="urn:gooo:recorded-use:usageclaim" kind="entity"
//gooo:generated:start id="urn:gooo:recorded-use:explain" kind="activity"
func Explain(input GoooRecord76b42d5002c15b91565ba15fc336e8a729fc8b2a584cb1b69642ffe7c6160539) string {

	var claim = Inspect(input)
	if claim.GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 == "SELECT_ONE_USE" {
		return "읽기 한 건을 선택해 조회해 주세요."
	}
	if claim.GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 == "INVALID_INPUT" {
		return "기록을 연결하는 입력이 서로 맞지 않습니다."
	}
	if claim.GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 == "UNRESOLVED_LOCAL_USE" {
		if claim.GoooField8eac8495791d8947a1ed9c5ce7e20ed669fefe05bbb423f8cc62998b21aa4ae7 == "NO_RECORDED_ASSIGNMENT" {
			return "이 읽기에 연결된 대입이 보관되어 있지 않습니다."
		}
		if claim.GoooField8eac8495791d8947a1ed9c5ce7e20ed669fefe05bbb423f8cc62998b21aa4ae7 == "WRITE_LIMIT" {
			return "대입 기록 한도로 값 버전의 기원을 확인하지 못했습니다."
		}
		return "보관된 기록에서 읽기의 기원을 확인하지 못했습니다."
	}
	if claim.GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 == "RECORDED_GENERATION_AND_USAGE" {
		var message = "호출이 기록된 값 버전을 읽었습니다."
		if len(claim.GoooFielde6d52acadc1e7d799453fb2b7d1ae37caa2470fd16a3789728294ffa8c2cb44a) <= 128 {
			message = "호출이 '" + claim.GoooFielde6d52acadc1e7d799453fb2b7d1ae37caa2470fd16a3789728294ffa8c2cb44a + "'의 기록된 값 버전을 읽었습니다."
		}
		message = message + " 같은 기록에서 이 버전의 대입 완료를 확인했습니다."
		if claim.GoooFieldc54d4a523b64dbe234b119bedd248c3f27cf8db5f7ebb6d9cfaee98abc51459e == "UNMAPPED" {
			message = message + " 기록된 읽기의 소스 위치는 미확정입니다."
		}
		if claim.GoooFielde04af8c1c8cef09350e83349c1e97ed990e02baa00e721bab3c0e203e5fcf273 {
			message = message + " 기록 한도에 걸린 부분이 있습니다."
		}
		return message
	}
	return "이 판정 상태의 설명이 아직 정의되지 않았습니다."

}

//gooo:generated:end id="urn:gooo:recorded-use:explain" kind="activity"
//gooo:generated:start id="urn:gooo:recorded-use:inspect" kind="activity"
func Inspect(input GoooRecord76b42d5002c15b91565ba15fc336e8a729fc8b2a584cb1b69642ffe7c6160539) GoooRecord6a094015dd891a5e0d6ca6894f4b55220141059d5334eaa7dbf50aec90b903a8 {

	var claim = GoooRecord6a094015dd891a5e0d6ca6894f4b55220141059d5334eaa7dbf50aec90b903a8{
		GoooField23f68dfebcdf28a57bcc8a8c75044cf6d621c8172573f0011b00395075469afc: input.GoooFielde54f16594be5da52be09d5dfeac22429e9565ba3950f9ed21dfe439f19a10779,
		GoooField6856f212c0ccd02675ec4adf896335151c9f3af2ff9905721a1e90742b22c174: input.GoooField05b6775902feb9dce9def1b7a950ceac973825e48852cb7b94520ea57582020a,
		GoooFieldf700233d2b41e1222aacb1e0c0c567c702481436580b9be82b834bdc41410c86: input.GoooField5ce85dd712d551ff89fb90b7e83184ba7dc6b9cfc95469029d8af088d141a251,
		GoooFieldadfeb8685a0470bfb5dc3b7bfce2ba50905c995652f2ffe07092edbf01150233: "saved_json_bytes",
		GoooField46cebd890d285765182b716d7a9aedd4a65fba981c9d739b5a5545c030f17eb2: "",
		GoooFieldc8b4e1f00bfab81d831fc73ccf9222454d0f9a8044c65e2cc2ae069f1ca4c385: "",
		GoooFieldaf5ece6d06cb08fa047caf8ad7308e63b7744584b9f72e1ced45182e9743cb9a: -1,
		GoooFielde780cbb25d697508723dfe3bf9b9dd9105eea802781571aa9442c2d1e89a5766: -1,
		GoooFielde4a11cb83a1d7c75da5aaf28dee4f368cb2c68413048316661496def2ec5a544: -1,
		GoooField65142565ed946340e600a2b8c376b24978561a092b7783c1ed43af9490e612c9: -1,
		GoooField7a2d185f61a292306f857e834009d18fd6db0654a5716a504144533b5c0cdd5c: "",
		GoooField0efc673341596d46a66c35d899a7c37a7d7620bcba0e0d494168fc0bdb7390f1: "",
		GoooField29e81268ce7284c43279bf9ce1d39bd0e84bc7a85c0d4fc11da02e28e44b2f52: -1,
		GoooField69fe4f763338cac4b46633c3a1c8ac8dd6a295cce320bb08177914e83f2b7afe: "",
		GoooFielde6d52acadc1e7d799453fb2b7d1ae37caa2470fd16a3789728294ffa8c2cb44a: "",
		GoooField4c68fad4c98034af94a83c4ff75929a3597b70bb59b64e0aec709234c8668aef: -1,
		GoooFieldf331747d0651949f99fbe69b431174b61323f53f69240baebcefb8ab6e4b27e8: "",
		GoooField62542dba55208cb65f415abdd266ba02912062f61c94ae80f16216eb236b120e: "",
		GoooField274b01ced899f84b352923f121df1f40c6544b42b4693e1ac199373c11af3aef: 0,
		GoooFieldab9d5d408fe59773829d194269b8100d2feec445c258f2a1fdc89801b63b5fc0: 0,
		GoooFieldc54d4a523b64dbe234b119bedd248c3f27cf8db5f7ebb6d9cfaee98abc51459e: "UNMAPPED",
		GoooFielde04af8c1c8cef09350e83349c1e97ed990e02baa00e721bab3c0e203e5fcf273: false,
		GoooField8eac8495791d8947a1ed9c5ce7e20ed669fefe05bbb423f8cc62998b21aa4ae7: "",
		GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640: "INVALID_INPUT",
	}
	var count = int64(len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4))
	if input.GoooFielde54f16594be5da52be09d5dfeac22429e9565ba3950f9ed21dfe439f19a10779 == "" || input.GoooField05b6775902feb9dce9def1b7a950ceac973825e48852cb7b94520ea57582020a == "" || input.GoooField5ce85dd712d551ff89fb90b7e83184ba7dc6b9cfc95469029d8af088d141a251 == "" ||
		input.GoooField9f70e7895605c6d69656e699b5fab8b367893f4186bd70976a77a1932527b42c < 0 || input.GoooField0ff1b2773efaed4ac30768d497869a8bf20fcf00533a548c4a73baa49fc6100a < count || input.GoooField9f70e7895605c6d69656e699b5fab8b367893f4186bd70976a77a1932527b42c > input.GoooField0ff1b2773efaed4ac30768d497869a8bf20fcf00533a548c4a73baa49fc6100a-count ||
		input.GoooField796e84a119ba1aab5120374a13b9bf8335f18357fff864fb29b467261b8a7bf8 < 0 || input.GoooFielddced1c23b00564ae40804f7062814b577a8f1481b8e933d9b31461960ef5c2f5 < 0 || input.GoooField13f6da2ee6b7d6fdbb216a69f6c75aa321e5f84e972ab6933beb10c9c3f34320 < 0 {
		return claim
	}
	if len(input.GoooField9ce805e12017518a03dcd54fe36ebc08ffe82594dec60694f889261de9f8c924) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField245010b77888ef2f88c943698af6858be8aa6d5ff1746610e3efd383b839392a) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField16ff0d90fd42acc7897f1da6fe4eb25511202a330e109f46e9b9193596bdd223) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField4ad5c2f3fbd8b996d10dd2582b6df3257f4f8443754fd81a1b4154b48c957877) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField5923dd6d3182deb6aa2ddeb89c2351df5c9880f5c29b7cc810d113a6598dd633) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooFieldbaf2fdc95f656a6293b82956b1a858c0a78a1c6b449ef0dfe4c35a0633ad626f) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField9b7741b93c335f1a42721aef3b1bb87518119e80ed06ebf0c0c5d1357edada8e) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooFieldb5ef0743355cccdeb0b253aa22a7357fd16cb61af335a0ca1559565b13f3bee5) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField0f2deb0c3105e58e37e25da0a88a69337af46ef2828f255d838bc154f3ec3079) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField4376cfdedcebf007d2669d19e40b85204ffed3ec86f0d66e01623edfae1e1f4c) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooFieldcbe3e8a02997fc1ca1c482cd9b5a89ae8acd58ebd18e63b69278741bccdd694f) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooFieldf573594c0dc321d5cd0fd365dc20947049dfb992e255d8428c019acd8564b8da) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooFieldd60f008f172fff5d266d76d4feb368f9f37724780a87e3ecfa8a3a2fe1d33861) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField1e619c42c3debfddc974efd3723078ffe7dc3007a05ed4f4c2a9e5ce8c5e2c04) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField8ff92740d6a0ec2b5ac9c4719a27a0b1b40d0be2fb59606c3d9a999f44280efd) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField493ba281a7a1ecc5330c0ab7d1a00f35f9224e83ed33b2352bc3db4893a8ba39) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) ||
		len(input.GoooField817b021f2ce4cbdc3624db8342ec2b75c91cb391510e3d6e43e630520a7b4750) != len(input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4) {
		return claim
	}
	if count != 1 {
		claim.GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 = "SELECT_ONE_USE"
		return claim
	}
	if input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4[0] < 0 || input.GoooField9ce805e12017518a03dcd54fe36ebc08ffe82594dec60694f889261de9f8c924[0] < 0 || input.GoooField245010b77888ef2f88c943698af6858be8aa6d5ff1746610e3efd383b839392a[0] < 0 ||
		input.GoooField4ad5c2f3fbd8b996d10dd2582b6df3257f4f8443754fd81a1b4154b48c957877[0] == "" || input.GoooField5923dd6d3182deb6aa2ddeb89c2351df5c9880f5c29b7cc810d113a6598dd633[0] == "" || input.GoooField8ff92740d6a0ec2b5ac9c4719a27a0b1b40d0be2fb59606c3d9a999f44280efd[0] == "" ||
		input.GoooField493ba281a7a1ecc5330c0ab7d1a00f35f9224e83ed33b2352bc3db4893a8ba39[0] < 0 || input.GoooField817b021f2ce4cbdc3624db8342ec2b75c91cb391510e3d6e43e630520a7b4750[0] == "" {
		return claim
	}
	if input.GoooField1e619c42c3debfddc974efd3723078ffe7dc3007a05ed4f4c2a9e5ce8c5e2c04[0] == "MAPPED" {
		if input.GoooFieldcbe3e8a02997fc1ca1c482cd9b5a89ae8acd58ebd18e63b69278741bccdd694f[0] == "" || input.GoooFieldf573594c0dc321d5cd0fd365dc20947049dfb992e255d8428c019acd8564b8da[0] < 0 || input.GoooFieldd60f008f172fff5d266d76d4feb368f9f37724780a87e3ecfa8a3a2fe1d33861[0] <= input.GoooFieldf573594c0dc321d5cd0fd365dc20947049dfb992e255d8428c019acd8564b8da[0] {
			return claim
		}
	} else {
		if input.GoooField1e619c42c3debfddc974efd3723078ffe7dc3007a05ed4f4c2a9e5ce8c5e2c04[0] != "UNMAPPED" || input.GoooFieldcbe3e8a02997fc1ca1c482cd9b5a89ae8acd58ebd18e63b69278741bccdd694f[0] != "" ||
			input.GoooFieldf573594c0dc321d5cd0fd365dc20947049dfb992e255d8428c019acd8564b8da[0] != 0 || input.GoooFieldd60f008f172fff5d266d76d4feb368f9f37724780a87e3ecfa8a3a2fe1d33861[0] != 0 {
			return claim
		}
	}
	if input.GoooFieldbaf2fdc95f656a6293b82956b1a858c0a78a1c6b449ef0dfe4c35a0633ad626f[0] {
		if input.GoooField16ff0d90fd42acc7897f1da6fe4eb25511202a330e109f46e9b9193596bdd223[0] < 0 || input.GoooField9b7741b93c335f1a42721aef3b1bb87518119e80ed06ebf0c0c5d1357edada8e[0] != "" || !input.GoooField4376cfdedcebf007d2669d19e40b85204ffed3ec86f0d66e01623edfae1e1f4c[0] ||
			input.GoooFieldb5ef0743355cccdeb0b253aa22a7357fd16cb61af335a0ca1559565b13f3bee5[0] != input.GoooField245010b77888ef2f88c943698af6858be8aa6d5ff1746610e3efd383b839392a[0] || input.GoooField0f2deb0c3105e58e37e25da0a88a69337af46ef2828f255d838bc154f3ec3079[0] != input.GoooField5923dd6d3182deb6aa2ddeb89c2351df5c9880f5c29b7cc810d113a6598dd633[0] {
			return claim
		}
		claim.GoooField46cebd890d285765182b716d7a9aedd4a65fba981c9d739b5a5545c030f17eb2 = "http://www.w3.org/ns/prov#wasGeneratedBy"
		claim.GoooFieldc8b4e1f00bfab81d831fc73ccf9222454d0f9a8044c65e2cc2ae069f1ca4c385 = "http://www.w3.org/ns/prov#used"
		claim.GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 = "RECORDED_GENERATION_AND_USAGE"
	} else {
		if input.GoooFieldb5ef0743355cccdeb0b253aa22a7357fd16cb61af335a0ca1559565b13f3bee5[0] != -1 || input.GoooField0f2deb0c3105e58e37e25da0a88a69337af46ef2828f255d838bc154f3ec3079[0] != "" || input.GoooField4376cfdedcebf007d2669d19e40b85204ffed3ec86f0d66e01623edfae1e1f4c[0] {
			return claim
		}
		var known_reason = input.GoooField16ff0d90fd42acc7897f1da6fe4eb25511202a330e109f46e9b9193596bdd223[0] == -1 && input.GoooField9b7741b93c335f1a42721aef3b1bb87518119e80ed06ebf0c0c5d1357edada8e[0] == "NO_RECORDED_ASSIGNMENT"
		if input.GoooField16ff0d90fd42acc7897f1da6fe4eb25511202a330e109f46e9b9193596bdd223[0] == -2 && input.GoooField9b7741b93c335f1a42721aef3b1bb87518119e80ed06ebf0c0c5d1357edada8e[0] == "WRITE_LIMIT" && input.GoooFielddced1c23b00564ae40804f7062814b577a8f1481b8e933d9b31461960ef5c2f5 > 0 {
			known_reason = true
		}
		if !known_reason {
			return claim
		}
		claim.GoooField0b220bd96385a92dd59d8cbbe6b7ceba4fc4a40619cd3aa9683fe97b3227a640 = "UNRESOLVED_LOCAL_USE"
	}
	claim.GoooFieldaf5ece6d06cb08fa047caf8ad7308e63b7744584b9f72e1ced45182e9743cb9a = input.GoooField3163551988f1104464545e665756b23e99468a3c5bc25a503040895a50e830e4[0]
	claim.GoooFielde780cbb25d697508723dfe3bf9b9dd9105eea802781571aa9442c2d1e89a5766 = input.GoooField9ce805e12017518a03dcd54fe36ebc08ffe82594dec60694f889261de9f8c924[0]
	claim.GoooFielde4a11cb83a1d7c75da5aaf28dee4f368cb2c68413048316661496def2ec5a544 = input.GoooField245010b77888ef2f88c943698af6858be8aa6d5ff1746610e3efd383b839392a[0]
	claim.GoooField65142565ed946340e600a2b8c376b24978561a092b7783c1ed43af9490e612c9 = input.GoooField16ff0d90fd42acc7897f1da6fe4eb25511202a330e109f46e9b9193596bdd223[0]
	claim.GoooField7a2d185f61a292306f857e834009d18fd6db0654a5716a504144533b5c0cdd5c = input.GoooField4ad5c2f3fbd8b996d10dd2582b6df3257f4f8443754fd81a1b4154b48c957877[0]
	claim.GoooField0efc673341596d46a66c35d899a7c37a7d7620bcba0e0d494168fc0bdb7390f1 = input.GoooField5923dd6d3182deb6aa2ddeb89c2351df5c9880f5c29b7cc810d113a6598dd633[0]
	claim.GoooField29e81268ce7284c43279bf9ce1d39bd0e84bc7a85c0d4fc11da02e28e44b2f52 = input.GoooFieldb5ef0743355cccdeb0b253aa22a7357fd16cb61af335a0ca1559565b13f3bee5[0]
	claim.GoooField69fe4f763338cac4b46633c3a1c8ac8dd6a295cce320bb08177914e83f2b7afe = input.GoooField0f2deb0c3105e58e37e25da0a88a69337af46ef2828f255d838bc154f3ec3079[0]
	claim.GoooFielde6d52acadc1e7d799453fb2b7d1ae37caa2470fd16a3789728294ffa8c2cb44a = input.GoooField8ff92740d6a0ec2b5ac9c4719a27a0b1b40d0be2fb59606c3d9a999f44280efd[0]
	claim.GoooField4c68fad4c98034af94a83c4ff75929a3597b70bb59b64e0aec709234c8668aef = input.GoooField493ba281a7a1ecc5330c0ab7d1a00f35f9224e83ed33b2352bc3db4893a8ba39[0]
	claim.GoooFieldf331747d0651949f99fbe69b431174b61323f53f69240baebcefb8ab6e4b27e8 = input.GoooField817b021f2ce4cbdc3624db8342ec2b75c91cb391510e3d6e43e630520a7b4750[0]
	claim.GoooField62542dba55208cb65f415abdd266ba02912062f61c94ae80f16216eb236b120e = input.GoooFieldcbe3e8a02997fc1ca1c482cd9b5a89ae8acd58ebd18e63b69278741bccdd694f[0]
	claim.GoooField274b01ced899f84b352923f121df1f40c6544b42b4693e1ac199373c11af3aef = input.GoooFieldf573594c0dc321d5cd0fd365dc20947049dfb992e255d8428c019acd8564b8da[0]
	claim.GoooFieldab9d5d408fe59773829d194269b8100d2feec445c258f2a1fdc89801b63b5fc0 = input.GoooFieldd60f008f172fff5d266d76d4feb368f9f37724780a87e3ecfa8a3a2fe1d33861[0]
	claim.GoooFieldc54d4a523b64dbe234b119bedd248c3f27cf8db5f7ebb6d9cfaee98abc51459e = input.GoooField1e619c42c3debfddc974efd3723078ffe7dc3007a05ed4f4c2a9e5ce8c5e2c04[0]
	claim.GoooFielde04af8c1c8cef09350e83349c1e97ed990e02baa00e721bab3c0e203e5fcf273 = input.GoooField796e84a119ba1aab5120374a13b9bf8335f18357fff864fb29b467261b8a7bf8 > 0 || input.GoooFielddced1c23b00564ae40804f7062814b577a8f1481b8e933d9b31461960ef5c2f5 > 0 || input.GoooField13f6da2ee6b7d6fdbb216a69f6c75aa321e5f84e972ab6933beb10c9c3f34320 > 0
	claim.GoooField8eac8495791d8947a1ed9c5ce7e20ed669fefe05bbb423f8cc62998b21aa4ae7 = input.GoooField9b7741b93c335f1a42721aef3b1bb87518119e80ed06ebf0c0c5d1357edada8e[0]
	return claim

}

//gooo:generated:end id="urn:gooo:recorded-use:inspect" kind="activity"
