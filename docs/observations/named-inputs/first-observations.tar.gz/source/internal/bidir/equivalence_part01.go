package bidir

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strings"
)

func nodeSemanticEqual(left, right Node) bool {
	if !equalInputNames(left.InputNames, right.InputNames) {
		return false
	}
	if left.ID != right.ID || left.Kind != right.Kind || !stringMapEqual(left.Attributes, right.Attributes) || len(left.Fields) != len(right.Fields) || len(left.InputSequence) != len(right.InputSequence) {
		return false
	}
	for index := range left.InputSequence {
		if left.InputSequence[index].ID != right.InputSequence[index].ID {
			return false
		}
	}
	for index := range left.Fields {
		if !fieldSemanticEqual(left.Fields[index], right.Fields[index]) {
			return false
		}
	}
	return true
}
func relationSemanticEqual(left, right Relation) bool {
	return left.Kind == right.Kind && left.Source == right.Source && left.Target == right.Target && stringMapEqual(left.Attributes, right.Attributes)
}

// SemanticEquivalent ignores presentation, source spans, and candidates.
func SemanticEquivalent(left, right Model) bool {
	left, right = left.Normalized(), right.Normalized()
	if len(left.Nodes) != len(right.Nodes) || len(left.Relations) != len(right.Relations) || len(left.RuntimeBindings) != len(right.RuntimeBindings) {
		return false
	}
	for index := range left.Nodes {
		if !nodeSemanticEqual(left.Nodes[index], right.Nodes[index]) {
			return false
		}
	}
	for index := range left.Relations {
		if !relationSemanticEqual(left.Relations[index], right.Relations[index]) {
			return false
		}
	}
	leftBindings, rightBindings := sortedModelRuntimeBindings(left.RuntimeBindings), sortedModelRuntimeBindings(right.RuntimeBindings)
	for index := range leftBindings {
		if runtimeBindingKey(leftBindings[index]) != runtimeBindingKey(rightBindings[index]) || leftBindings[index].Entity != rightBindings[index].Entity {
			return false
		}
	}
	return true
}

// SemanticallyEquivalent is the method form of SemanticEquivalent.
func (m Model) SemanticallyEquivalent(other Model) bool {
	return SemanticEquivalent(m, other)
}

// SemanticFingerprint is a stable digest of the fields used by equivalence.
func SemanticFingerprint(model Model) string {
	model = model.Normalized()
	var canonical strings.Builder
	for _, node := range model.Nodes {
		writeFingerprintPart(&canonical, string(node.ID))
		writeFingerprintPart(&canonical, string(node.Kind))
		writeMapFingerprint(&canonical, node.Attributes)
		if len(node.InputNames) > 0 {
			writeFingerprintPart(&canonical, fmt.Sprintf("input-names/%d", len(node.InputNames)))
			for _, name := range node.InputNames {
				writeFingerprintPart(&canonical, name.Name)
			}
		}
		if len(node.InputSequence) > 0 {
			writeFingerprintPart(&canonical, fmt.Sprintf("input-sequence/%d", len(node.InputSequence)))
			for _, input := range node.InputSequence {
				writeFingerprintPart(&canonical, string(input.ID))
			}
		}
		for _, field := range node.Fields {
			writeFieldSemanticFingerprint(&canonical, field)
		}
	}
	canonical.WriteByte('|')
	for _, relation := range model.Relations {
		writeFingerprintPart(&canonical, string(relation.Kind))
		writeFingerprintPart(&canonical, string(relation.Source))
		writeFingerprintPart(&canonical, string(relation.Target))
		writeMapFingerprint(&canonical, relation.Attributes)
	}
	for _, binding := range sortedModelRuntimeBindings(model.RuntimeBindings) {
		if binding.Feedback {
			writeFingerprintPart(&canonical, "feedback")
		}
		writeFingerprintPart(&canonical, string(binding.Producer.Activity.ID))
		writeFingerprintPart(&canonical, binding.Producer.Port.Name)
		writeFingerprintPart(&canonical, string(binding.Consumer.Activity.ID))
		writeFingerprintPart(&canonical, binding.Consumer.Port.Name)
		writeFingerprintPart(&canonical, string(binding.Entity))
	}
	digest := sha256.Sum256([]byte(canonical.String()))
	return hex.EncodeToString(digest[:])
}
func writeFingerprintPart(builder *strings.Builder, value string) {
	fmt.Fprintf(builder, "%d:", len(value))
	builder.WriteString(value)
}
