package semantic

import "github.com/kimjooyoon/meta-ontology-go/internal/assemblyspec"

// Node is a semantic declaration. Name and Aliases are presentation and
// lookup metadata; ID, Kind, Namespace, latent field structure, and an
// optional activity value program and assembly contract are the semantic boundary.
// Fields are valid only on Entity nodes; ValueProgram is valid only on
// Activity nodes. Assembly carries source intent, typed choices and finite cases;
// execution observations are separate.
type Node struct {
	ID            ID
	Kind          Kind
	Namespace     Namespace
	Name          string
	Aliases       []string
	Fields        []Field            `json:"fields,omitempty"`
	ValueProgram  string             `json:"value_program,omitempty"`
	InputSequence []ID               `json:"input_sequence,omitempty"`
	InputNames    []InputName        `json:"input_names,omitempty"`
	Assembly      *assemblyspec.Spec `json:"assembly,omitempty"`
	Span          Span
}

func NewNode(kind Kind, id ID, namespace Namespace, name string) (Node, error) {
	node := Node{ID: id, Kind: kind, Namespace: namespace, Name: name}
	return node.Normalized()
}
func NewNodeFromStrings(kind Kind, id, namespace, name string) (Node, error) {
	parsedID, err := ParseIdentity(id)
	if err != nil {
		return Node{}, err
	}
	parsedNamespace, err := ParseNamespace(namespace)
	if err != nil {
		return Node{}, err
	}
	return NewNode(kind, parsedID, parsedNamespace, name)
}
func NewEntity(id ID, namespace Namespace, name string) (Node, error) {
	return NewNode(Entity, id, namespace, name)
}
func NewActivity(id ID, namespace Namespace, name string) (Node, error) {
	return NewNode(Activity, id, namespace, name)
}
func NewAgent(id ID, namespace Namespace, name string) (Node, error) {
	return NewNode(Agent, id, namespace, name)
}
