package semantic

import (
	"fmt"
	"slices"
)

func (n Node) Normalized() (Node, error) {
	id, err := ParseIdentity(n.ID.String())
	if err != nil {
		return Node{}, fmt.Errorf("%w: id: %v", ErrInvalidNode, err)
	}
	ns, err := ParseNamespace(n.Namespace.String())
	if err != nil {
		return Node{}, fmt.Errorf("%w: namespace: %v", ErrInvalidNode, err)
	}
	if !n.Kind.Valid() {
		return Node{}, fmt.Errorf("%w: unknown kind %q", ErrInvalidNode, n.Kind)
	}
	name, err := normalizeName(n.Name)
	if err != nil {
		return Node{}, fmt.Errorf("%w: name: %v", ErrInvalidNode, err)
	}
	aliases, err := normalizeAliases(n.Aliases, name)
	if err != nil {
		return Node{}, fmt.Errorf("%w: aliases: %v", ErrInvalidNode, err)
	}
	span := n.Span.Normalized()
	if err := span.Validate(); err != nil {
		return Node{}, fmt.Errorf("%w: span: %v", ErrInvalidNode, err)
	}
	fields, err := normalizeFields(n.Fields, id, n.Kind)
	if err != nil {
		return Node{}, fmt.Errorf("%w: fields: %w", ErrInvalidNode, err)
	}
	valueProgram, err := normalizeActivityValueProgram(n.Kind, n.ValueProgram)
	if err != nil {
		return Node{}, err
	}
	if len(n.InputSequence) > 0 {
		if n.Kind != Activity || len(n.InputSequence) < 2 {
			return Node{}, fmt.Errorf("%w: input sequence requires a multi-input Activity", ErrInvalidNode)
		}
		n.InputSequence = append([]ID(nil), n.InputSequence...)
		for i, input := range n.InputSequence {
			id, err := ParseIdentity(input.String())
			if err != nil {
				return Node{}, fmt.Errorf("%w: input sequence: %v", ErrInvalidNode, err)
			}
			n.InputSequence[i] = id
		}
	}
	inputNames, err := normalizeInputNames(n.Kind, n.InputSequence, n.InputNames)
	if err != nil {
		return Node{}, err
	}
	n.InputNames = inputNames
	if n.Assembly != nil {
		if n.Kind != Activity || valueProgram == "" {
			return Node{}, fmt.Errorf("%w: assembly requires an Activity value program", ErrInvalidNode)
		}
		if err := n.Assembly.Validate(); err != nil {
			return Node{}, fmt.Errorf("%w: %v", ErrInvalidNode, err)
		}
		n.Assembly = n.Assembly.Clone()
	}

	n.ID = id
	n.Namespace = ns
	n.Name = name
	n.Aliases = aliases
	n.Fields = fields
	n.ValueProgram = valueProgram
	n.Span = span
	return n, nil
}
func (n Node) Validate() error {
	_, err := n.Normalized()
	return err
}
func (n Node) NameRef() NameRef {
	return NameRef{Namespace: n.Namespace, Name: n.Name}
}
func (n Node) HasName(name string) bool {
	canonical, err := normalizeName(name)
	if err != nil {
		return false
	}
	if n.Name == canonical {
		return true
	}
	return slices.Contains(n.Aliases, canonical)
}
