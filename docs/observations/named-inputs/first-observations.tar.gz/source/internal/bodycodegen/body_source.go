package bodycodegen

import (
	"fmt"

	"github.com/kimjooyoon/meta-ontology-go/internal/bidir"
	"github.com/kimjooyoon/meta-ontology-go/internal/syntax"
)

type preparedBody struct {
	activity                                  *syntax.ActivityDecl
	packageName, activityID, outputType, body string
	parameters                                []InputParameter
	records                                   []RecordType
	base                                      generatedRoute
	file                                      *syntax.File
	allRecords                                []RecordType
	activityIDs                               map[string]string
	entityIDs                                 map[string]string
}

func prepareActivityBody(filename string, source []byte, activityName string) (preparedBody, error) {
	p, err := prepareActivityBodySource(filename, source, activityName)
	if err == nil {
		p.base, err = p.generate(preserveRoute)
	}
	return p, err
}

// Prepare source identities and types before a search replaces its body hole.
func prepareActivityBodySource(filename string, source []byte, activityName string) (preparedBody, error) {
	var p preparedBody
	file, diagnostics := ParseBodyFile(filename, source)
	if diagnostics.HasErrors() {
		return p, fmt.Errorf("parse .gooo source: %w", diagnostics.Error())
	}
	if file == nil || file.Package == nil {
		return p, fmt.Errorf(".gooo source has no package declaration")
	}
	var err error
	p.activity, err = sourceBodyActivity(file, activityName)
	if err != nil {
		return p, err
	}
	model, records, err := resolveBodyModel(file)
	if err != nil {
		return p, err
	}
	p.parameters, err = sourceBodyParameters(p.activity, records, file)
	if err != nil {
		return p, err
	}
	var ok bool
	p.outputType, ok = bodyEntityType(p.activity.Output, records, file)
	if !ok {
		return p, fmt.Errorf("activity %q output entity %q is outside the pure value profile", activityName, p.activity.Output)
	}
	p.records = activityRecords(records, p.parameters, p.outputType, p.activity.ValueProgram)
	p.file, p.allRecords, p.activityIDs = file, records, map[string]string{}
	p.entityIDs = map[string]string{}
	for _, node := range model.Nodes {
		if node.Kind == bidir.ActivityKind {
			p.activityIDs[node.Name] = string(node.ID)
		}
		if node.Kind == bidir.EntityKind {
			p.entityIDs[node.Name] = string(node.ID)
		}
	}
	p.activityID = p.activityIDs[activityName]
	if p.activityID == "" {
		return p, fmt.Errorf("activity %q has no stable semantic identity", activityName)
	}
	p.packageName = file.Package.Name
	p.body, err = rewriteLetDeclarations(p.activity.ValueProgram)
	return p, err
}

func sourceBodyActivity(file *syntax.File, name string) (*syntax.ActivityDecl, error) {
	for _, declaration := range file.Declarations {
		activity, ok := declaration.(*syntax.ActivityDecl)
		if !ok || activity.Name != name {
			continue
		}
		if !activity.ValueProgramPresent || activity.ValueProgram == "" {
			return nil, fmt.Errorf("activity %q has no computes body", name)
		}
		return activity, nil
	}
	return nil, fmt.Errorf("activity %q was not found", name)
}

func sourceBodyParameters(activity *syntax.ActivityDecl, records []RecordType, files ...*syntax.File) ([]InputParameter, error) {
	if len(activity.Inputs) < 1 || len(activity.Inputs) > 16 {
		return nil, fmt.Errorf("activity %q requires 1..16 inputs, got %d", activity.Name, len(activity.Inputs))
	}
	parameters := make([]InputParameter, len(activity.Inputs))
	names, err := syntax.ActivityInputNames(activity)
	if err != nil {
		return nil, err
	}
	for i, input := range activity.Inputs {
		inputType, ok := bodyEntityType(input.Name, records, files...)
		if !ok {
			return nil, fmt.Errorf("activity %q input entity %q is outside the pure value profile", activity.Name, input.Name)
		}
		parameters[i] = InputParameter{Name: names[i], Type: inputType}
	}
	return parameters, nil
}

func (p preparedBody) generate(route string) (generatedRoute, error) {
	return p.generateBody(p.body, route)
}
