package bodycodegen

//gooo:generated:start id="urn:gooo:body-surface:join-else" kind="activity"
func JoinElse(input0 bool, input1 bool, input2 bool, input3 bool) bool {

	var else_token = input0
	var inserted_linebreak = input1
	var closing_brace = input2
	var whitespace_gap = input3
	return else_token && inserted_linebreak && closing_brace && whitespace_gap

}

//gooo:generated:end id="urn:gooo:body-surface:join-else" kind="activity"
