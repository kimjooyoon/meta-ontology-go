package bodycodegen

import (
 "go/parser"
 "go/scanner"
 "go/token"
 "strings"
 "testing"
)

type observedToken struct {kind token.Token;literal string;start,end int}
func joinedLayout(body string) string {
 set:=token.NewFileSet();file:=set.AddFile("authored",-1,len(body));var scan scanner.Scanner
 scan.Init(file,[]byte(body),nil,scanner.ScanComments)
 tokens:=[]observedToken{}
 for {at,kind,text:=scan.Scan();if kind==token.EOF {break};if kind==token.COMMENT {continue};if text=="" {text=kind.String()};start:=file.Offset(at);tokens=append(tokens,observedToken{kind,text,start,start+len(text)})}
 out:=[]byte(body)
 for i,current:=range tokens {
  if i<2 {continue}
  before:=tokens[i-2];previous:=tokens[i-1];if before.end>current.start {continue}
  gap:=body[before.end:current.start]
  allow:=JoinElse(current.kind==token.ELSE,previous.kind==token.SEMICOLON&&previous.literal=="\n",before.kind==token.RBRACE,strings.TrimSpace(gap)=="")
  if !allow {continue}
  for p:=before.end;p<current.start;p++ {if out[p]=='\n' {out[p]=' '}}
 }
 return string(out)
}

func TestGeneratedElsePolicyFreshLayouts(t *testing.T) {
 cases:=[]struct{name,body string;accept,changed bool}{
  {"LF source","if flag {return 101}\nelse {return 103}",true,true},
  {"CRLF source","if flag {return 107}\r\n else {return 109}",true,true},
  {"blank lines","if flag {return 113}\n\n\telse {return 127}",true,true},
  {"else body next line","if flag {return 131}\nelse\n{return 137}",true,true},
  {"nested else if","if flag {return 139}\nelse if !flag {return 149}\nelse {return 151}",true,true},
  {"nested block","if flag {if flag {return 157}\nelse {return 163}}\nelse {return 167}",true,true},
  {"Unicode alias and literal","문구 := \"}\\nelse\";_ = 문구;if flag {return 173}\nelse {return 179}",true,true},
  {"same line remains byte identical","if flag {return 181} else {return 191}",true,false},
  {"line comment retained","if flag {return 193} // source\nelse {return 197}",false,false},
  {"block comment retained","if flag {return 199}\n/* source */\nelse {return 211}",false,false},
  {"explicit separator retained","if flag {return 223};\nelse {return 227}",false,false},
 }
 for _,c:=range cases {t.Run(c.name,func(t *testing.T){
  actual:=joinedLayout(c.body);if len(actual)!=len(c.body) {t.Fatal("source byte width changed")}
  if (actual!=c.body)!=c.changed {t.Fatal("unexpected surface mutation")}
  for i:=range len(actual) {if actual[i]!=c.body[i]&&(actual[i]!=' '||c.body[i]!='\n') {t.Fatal("changed non-layout byte",i)}}
  _,err:=parser.ParseFile(token.NewFileSet(),"projection.go","package p\nfunc choose(flag bool)int64 {\n"+actual+"\n}",0)
  if (err==nil)!=c.accept {t.Fatal("parser outcome differs",err)}
 })}
}
