package main

import (
 "encoding/json"
 "go/parser"
 "go/scanner"
 "go/token"
 "os"
 "strings"
)

type item struct { kind token.Token; literal string; start, end int }
func normalize(body string) string {
 set:=token.NewFileSet();file:=set.AddFile("body",-1,len(body));var scan scanner.Scanner
 scan.Init(file,[]byte(body),nil,scanner.ScanComments)
 tokens:=[]item{}
 for { at,kind,text:=scan.Scan();if kind==token.EOF {break};if kind==token.COMMENT {continue};if text=="" {text=kind.String()};start:=file.Offset(at);tokens=append(tokens,item{kind,text,start,start+len(text)}) }
 out:=[]byte(body)
 for i,t:=range tokens {
  if t.kind!=token.ELSE || i<2 || tokens[i-1].kind!=token.SEMICOLON || tokens[i-1].literal!="\n" || tokens[i-2].kind!=token.RBRACE {continue}
  start:=tokens[i-2].end;gap:=body[start:t.start];if strings.TrimSpace(gap)!="" {continue}
  for p:=start;p<t.start;p++ {if out[p]=='\n' {out[p]=' '}}
 }
 return string(out)
}
func main() {
 cases:=[]struct{Name,Body string;Accept bool}{
  {"LF","if flag {return 17}\nelse {return 31}",true},
  {"CRLF","if flag {return 19}\r\nelse {return 37}",true},
  {"blank lines","if flag {return 23}\n\n else {return 41}",true},
  {"else if","if flag {return 29}\nelse if !flag {return 43}\nelse {return 47}",true},
  {"nested","if flag {if flag {return 31}\nelse {return 53}}\nelse {return 59}",true},
  {"literal and Unicode","가 := \"}\\nelse\";_ = 가;if flag {return 37}\nelse {return 61}",true},
  {"line comment gap","if flag {return 41} // keep comment\nelse {return 67}",false},
  {"block comment gap","if flag {return 43}\n/* keep comment */\nelse {return 71}",false},
  {"explicit semicolon","if flag {return 47};\nelse {return 73}",false},
 }
 rows:=[]map[string]any{};passed:=0
 for _,c:=range cases {out:=normalize(c.Body);_,err:=parser.ParseFile(token.NewFileSet(),"prototype.go","package p\nfunc choose(flag bool)int64 {\n"+out+"\n}",0);valid:=err==nil;equal:=len(out)==len(c.Body);if valid==c.Accept&&equal {passed++};rows=append(rows,map[string]any{"name":c.Name,"parse_accepted":valid,"expected":c.Accept,"byte_width_preserved":equal,"changed":out!=c.Body})}
 json.NewEncoder(os.Stdout).Encode(map[string]any{"scope":"standalone normalization/parser design probe, no repository compiler change or Gooo/native/model execution","passed":passed,"total":len(cases),"cases":rows})
 if passed!=len(cases) {os.Exit(1)}
}
