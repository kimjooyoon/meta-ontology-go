package syntaxregistration

import (
	"encoding/json"
	"go/ast"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"testing/fstest"
)

func TestSourceOwnedHistoryGrowth32031(t *testing.T) {
	data, request := fixture(t)
	delete(data, request.Case.Path)
	// Bind the complete prepared source view rather than the public predecessor.
	prepared := os.Getenv("GOOO_FRESH_FIELD_ROOT")
	err := filepath.WalkDir(prepared, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() {
			return nil
		}
		rel, err := filepath.Rel(prepared, path)
		if err != nil {
			return err
		}
		rel = filepath.ToSlash(rel)
		if _, exists := data[rel]; exists {
			raw, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			data[rel] = &fstest.MapFile{Data: raw}
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	initial := digestValue(data)
	initialCorpus := append([]byte(nil), data[corpusPath].Data...)
	var first Candidate
	for step := range 2 {
		request.BaseVersion = 72 + step
		request.Case.ID = []string{"historyorigin32031first", "historyorigin32031next"}[step]
		request.Case.Path = "examples/" + request.Case.ID + "/main.gooo"
		data[request.Case.Path] = &fstest.MapFile{Data: []byte(strings.ReplaceAll(fixtureSource, "registrationfixture", request.Case.ID))}
		pin(t, data, &request)
		plan, err := Compile(data, request)
		if err != nil {
			t.Fatal(err)
		}
		candidate, err := plan.Generate(data)
		if err != nil {
			t.Fatal(err)
		}
		if err := plan.ValidateCandidate(data, candidate); err != nil {
			t.Fatal(err)
		}
		if len(candidate.Artifacts) != 9 || candidate.ApplyAuthorized || candidate.RepositoryWrites != 0 {
			t.Fatal("history growth changed roles or authority")
		}
		for _, member := range candidate.Members {
			data[member.Path] = &fstest.MapFile{Data: member.Content}
		}
		inputs := map[string][]byte{}
		for name, file := range data {
			inputs[name] = file.Data
		}
		source, err := parseSourceUnits(inputs, closureRoot, "verticalsliceclosureshadow", false)
		if err != nil {
			t.Fatal(err)
		}
		freshAssertHistoryTarget32031(t, source, 72, 108)
		if step == 1 {
			freshAssertHistoryTarget32031(t, source, 73, 109)
		}
		var previous, current denominator
		if err := json.Unmarshal(data[denominatorPath(72+step)].Data, &previous); err != nil {
			t.Fatal(err)
		}
		if err := json.Unmarshal(data[denominatorPath(73+step)].Data, &current); err != nil {
			t.Fatal(err)
		}
		for index, expected := range previous.Boundaries {
			if index == 0 {
				expected.Target++
			}
			if current.Boundaries[index] != expected {
				t.Fatal("unrelated boundary or link target changed", index)
			}
		}
		if step == 0 {
			first = candidate
		}
	}
	if initial == digestValue(data) {
		t.Fatal("history continuation fixture did not change")
	}
	var baseline, final struct {
		Cases []json.RawMessage `json:"cases"`
	}
	if err := json.Unmarshal(initialCorpus, &baseline); err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(data[corpusPath].Data, &final); err != nil {
		t.Fatal(err)
	}
	if len(final.Cases) != 112 || !reflect.DeepEqual(final.Cases[:110], baseline.Cases) {
		t.Fatal("original110 source cases changed")
	}
	if out := os.Getenv("GOOO_FRESH_SOURCE_OUTPUT"); out != "" {
		raw, err := json.MarshalIndent(map[string]any{"first_candidate": first, "final_version": 74, "first_target": 109, "final_target": 110, "preserved_v72_target": 108, "artifact_roles": 9, "model_calls": 0}, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(out, "history32031.json"), raw, 0600); err != nil {
			t.Fatal(err)
		}
	}
}

func freshAssertHistoryTarget32031(t *testing.T, source *goSource, version, target int) {
	t.Helper()
	function, err := source.function("expectedBoundarySpecsForVersion")
	if err != nil {
		t.Fatal(err)
	}
	count := 0
	ast.Inspect(function.Body, func(node ast.Node) bool {
		clause, ok := node.(*ast.CaseClause)
		if !ok {
			return true
		}
		for _, expression := range clause.List {
			value, literal := integer(expression)
			if literal && value == version {
				count++
				assignment := clause.Body[0].(*ast.AssignStmt)
				value, literal = integer(assignment.Rhs[0])
				if !literal || value != target {
					t.Fatal("historical source target changed", version, value)
				}
			}
		}
		return true
	})
	if count != 1 {
		t.Fatal("historical source target missing or repeated", version, count)
	}
}
