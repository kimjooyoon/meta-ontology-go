package verticalsliceclosureshadow

import (
	"bytes"
	"github.com/kimjooyoon/meta-ontology-go/internal/meta/languagereadiness/languagesyntax"
	"os"
	"path/filepath"
	"testing"
)

func TestGeneratedOriginV7332591(t *testing.T) { freshGeneratedHistory32591(t, 73, 109) }
func TestGeneratedOriginV7432603(t *testing.T) { freshGeneratedHistory32591(t, 74, 110) }
func freshGeneratedHistory32591(t *testing.T, version, target int) {
	t.Helper()
	raw := activeDenominator()
	current, err := decodeDenominator(raw)
	if err != nil || current.Version != version || current.Boundaries[0].Target != target || target != languagesyntax.FixedCapabilityTotal || digestBytes(raw) != activeDenominatorDigest() {
		t.Fatal("generated active source binding", current, err)
	}
	if digestBytes(embeddedDenominatorV72) != DenominatorMigrationV72Digest {
		t.Fatal("v72 original bytes changed")
	}
	previous, err := decodeDenominator(embeddedDenominatorV72)
	if err != nil || previous.Version != 72 || previous.Boundaries[0].Target != 108 {
		t.Fatal("v72 lost its source-owned target", previous, err)
	}
	for index, expected := range previous.Boundaries {
		if index == 0 {
			expected.Target += version - 72
		}
		if current.Boundaries[index] != expected {
			t.Fatal("unrelated boundary or link changed", index)
		}
	}
	lowered := bytes.Replace(embeddedDenominatorV72, []byte("\"target\": 108"), []byte("\"target\": 107"), 1)
	if bytes.Equal(lowered, embeddedDenominatorV72) {
		t.Fatal("counterexample unchanged")
	}
	if _, err := decodeDenominator(lowered); err == nil {
		t.Fatal("historical target mutation accepted")
	}
	if version == 74 {
		raw, err := os.ReadFile(filepath.Join(os.Getenv("GOOO_FRESH_FIELD_ROOT"), "internal/meta/languageassurance/verticalsliceclosureshadow/evidence/denominator-v73.json"))
		if err != nil {
			t.Fatal(err)
		}
		prior, err := decodeDenominator(raw)
		if err != nil || prior.Version != 73 || prior.Boundaries[0].Target != 109 {
			t.Fatal("v73 acquired the current target", prior, err)
		}
	}
	t.Log("exact generated source:current", version, "target", target, "history72target108;5 other boundaries+13 links preserved;producer/model0")
}
