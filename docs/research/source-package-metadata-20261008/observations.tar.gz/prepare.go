package main

import (
	"encoding/json"
	"os"
	"path/filepath"
)

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func write(path string, value any) {
	raw, err := json.MarshalIndent(value, "", "  ")
	must(err)
	must(os.WriteFile(path, append(raw, '\n'), 0600))
}
func main() {
	if len(os.Args) != 3 {
		panic("provide library root and a new output directory")
	}
	library, root := os.Args[1], os.Args[2]
	must(os.Mkdir(root, 0700))
	var fixture struct {
		Cases []struct {
			Inputs   []json.RawMessage
			Expected json.RawMessage
		}
	}
	raw, err := os.ReadFile(filepath.Join(library, "fixtures/preview.json"))
	must(err)
	must(json.Unmarshal(raw, &fixture))
	var cases []any
	for _, c := range fixture.Cases {
		if len(c.Inputs) != 2 {
			panic("unexpected input arity")
		}
		cases = append(cases, map[string]any{
			"inputs":   map[string]json.RawMessage{"examples/preview:Plan.input0": c.Inputs[0], "examples/preview:Plan.input1": c.Inputs[1]},
			"expected": map[string]json.RawMessage{"examples/preview:Plan": c.Expected},
		})
	}
	for _, mode := range []string{"explicit", "source"} {
		dir := filepath.Join(root, mode)
		must(os.Mkdir(dir, 0700))
		for _, name := range []string{"gooo.workspace.json", "library/numbers.gooo", "library/logic.gooo", "library/text.gooo", "examples/preview.gooo", "examples/preview-inputs.json"} {
			raw, err := os.ReadFile(filepath.Join(library, name))
			must(err)
			target := filepath.Join(dir, name)
			must(os.MkdirAll(filepath.Dir(target), 0700))
			must(os.WriteFile(target, raw, 0600))
		}
		write(filepath.Join(dir, "cases.json"), map[string]any{"schema": "gooo/body-composition-cases/v1", "cases": cases})
		if mode == "source" {
			path := filepath.Join(dir, "gooo.workspace.json")
			raw, err := os.ReadFile(path)
			must(err)
			var m map[string]json.RawMessage
			must(json.Unmarshal(raw, &m))
			var pkgs []map[string]json.RawMessage
			must(json.Unmarshal(m["packages"], &pkgs))
			for _, p := range pkgs {
				delete(p, "name")
				delete(p, "imports")
			}
			m["packages"], err = json.Marshal(pkgs)
			must(err)
			write(path, m)
		}
	}
}
