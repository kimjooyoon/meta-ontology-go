package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
)

func read(path string) map[string]any {
	f, err := os.Open(path)
	must(err)
	defer f.Close()
	d := json.NewDecoder(f)
	d.UseNumber()
	var v map[string]any
	must(d.Decode(&v))
	return v
}
func must(err error) {
	if err != nil {
		panic(err)
	}
}
func at(v any, keys ...string) any {
	for _, k := range keys {
		v = v.(map[string]any)[k]
	}
	return v
}
func require(ok bool, message string) {
	if !ok {
		panic(message)
	}
}
func main() {
	if len(os.Args) != 2 {
		panic("provide the observation directory")
	}
	root := os.Args[1]
	explicit := read(filepath.Join(root, "explicit-resolution.json"))
	source := read(filepath.Join(root, "source-resolution.json"))
	require(explicit["decision"] == "PASS" && source["decision"] == "PASS", "resolution failed")
	require(reflect.DeepEqual(explicit["result"], source["result"]), "normalized graphs differ")
	require(explicit["manifest_digest"] != source["manifest_digest"], "manifest identity missing")
	baseline := read(filepath.Join(root, "explicit-fixed.json"))
	var records []any
	for _, name := range []string{"explicit-fixed", "source-fixed", "source-model", "source-replay"} {
		r := read(filepath.Join(root, name+".json"))
		require(r["decision"] == "PASS", "finite execution failed")
		require(at(r, "result", "runtime", "finite_passed") == json.Number("10"), "passed count differs")
		require(at(r, "result", "runtime", "finite_total") == json.Number("10"), "case denominator differs")
		require(at(r, "result", "runtime", "model_calls") == json.Number("0"), "runtime called a model")
		require(reflect.DeepEqual(at(r, "result", "runtime", "traces"), at(baseline, "result", "runtime", "traces")), "delivered values differ")
		require(at(r, "result", "composition", "generated_sha256") == at(baseline, "result", "composition", "generated_sha256"), "generated program differs")
		steps := at(r, "result", "composition", "steps").([]any)
		require(len(steps) == 1, "expected one constructed entry")
		assembly := at(steps[0], "generation", "report", "record_assembly")
		if name == "source-replay" {
			require(at(r, "result", "replay", "model_calls") == json.Number("0"), "replay called a model")
			require(r["replayed_from_sha256"] != nil, "replay has no prior identity")
		} else {
			want := json.Number("0")
			if name == "source-model" {
				want = "1"
			}
			require(at(assembly, "model_calls") == want, "construction model calls differ")
		}
		records = append(records, map[string]any{
			"operation": name, "passed": 10, "total": 10, "generated_sha256": at(r, "result", "composition", "generated_sha256"),
			"assembly": assembly, "model": at(r, "result", "composition", "model"), "replay": at(r, "result", "replay"),
		})
	}
	inputs := read(filepath.Join(root, "source-inputs.json"))
	require(inputs["decision"] == "OBSERVED", "input-only result gained a correctness decision")
	require(at(inputs, "result", "runtime", "finite_total") == json.Number("0") && at(inputs, "result", "runtime", "finite_passed") == json.Number("0"), "input-only result acquired expectations")
	require(at(inputs, "result", "replay", "model_calls") == json.Number("0") && at(inputs, "result", "runtime", "model_calls") == json.Number("0"), "input-only replay called a model")
	require(at(inputs, "result", "composition", "generated_sha256") == at(baseline, "result", "composition", "generated_sha256"), "input-only replay changed program")
	traces := at(inputs, "result", "runtime", "traces").([]any)
	require(len(traces) == 3, "input-only row count differs")
	var actuals []any
	for _, trace := range traces {
		ds := at(trace, "deliveries").([]any)
		require(len(ds) == 1, "input-only delivery count differs")
		d := ds[0].(map[string]any)
		_, expected := d["expected"]
		_, passed := d["passed"]
		require(!expected && !passed && d["actual"] != nil, "input-only output missing or acquired expectations")
		actuals = append(actuals, d["actual"])
	}
	result := map[string]any{
		"schema": "gooo/source-package-metadata-observation/v1", "compiler": read(filepath.Join(root, "build.json")),
		"resolution_equal": true, "manifest_digests_distinct": true, "consumer_programs": 1, "distinct_evaluation_inputs": 10,
		"runs": records, "input_only_actuals": actuals, "input_only_correctness": "UNKNOWN", "new_replay_model_calls": 0,
		"scope": "Previously frozen standard-library consumer; compiler regression using unchanged sources and model; no new training or generalization study.",
	}
	e := json.NewEncoder(os.Stdout)
	e.SetIndent("", "  ")
	must(e.Encode(result))
	fmt.Fprintln(os.Stderr, "PASS: exact normalized graph, delivered input/output traces and generated program; 10/10 expectations in each finite run; input-only replay has 3 records and no new inference.")
}
