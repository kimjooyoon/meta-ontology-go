package main

//gooo:generated:start id="callerhole://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	return GoooComposedActivity0Call0(input) + input
}
func GoooComposedActivity0Call0(input int64) int64 {
	var value int64 = 0
	return value
}

//gooo:generated:end id="callerhole://activity/main" kind="activity"
