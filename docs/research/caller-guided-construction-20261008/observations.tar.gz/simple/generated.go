package main

//gooo:generated:start id="caller://box" kind="entity"
type GoooRecordbd88a9f3ec60f733c6708c5c75e3c1cbddf3531d27c3d3a07522d67c7c318e82 struct {
	GoooFieldd7f4d0f7102d811444113458ef519c2a3e65124f13199ce6a4f7e476c0f2e989 int64 `json:"value"`
}

//gooo:generated:end id="caller://box" kind="entity"

//gooo:generated:start id="caller://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	var result = GoooComposedActivity0Call0(input)
	return result.GoooFieldd7f4d0f7102d811444113458ef519c2a3e65124f13199ce6a4f7e476c0f2e989
}
func GoooComposedActivity0Call0(input int64) GoooRecordbd88a9f3ec60f733c6708c5c75e3c1cbddf3531d27c3d3a07522d67c7c318e82 {
	return GoooRecordbd88a9f3ec60f733c6708c5c75e3c1cbddf3531d27c3d3a07522d67c7c318e82{GoooFieldd7f4d0f7102d811444113458ef519c2a3e65124f13199ce6a4f7e476c0f2e989: (input * 2)}
}

//gooo:generated:end id="caller://activity/main" kind="activity"
