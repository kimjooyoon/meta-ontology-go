package main

import (
	"encoding/json"
	"os"
)

func main() {
	var in [][1]json.RawMessage
	if json.NewDecoder(os.Stdin).Decode(&in) != nil || len(in) > 128 {
		os.Exit(2)
	}
	out := make([][1]json.RawMessage, len(in))
	for c, row := range in {
		var input0 int64
		if json.Unmarshal(row[0], &input0) != nil {
			os.Exit(2)
		}
		v0 := GoooComposedActivity0(input0)
		out[c][0], _ = json.Marshal(v0)
	}
	if json.NewEncoder(os.Stdout).Encode(out) != nil {
		os.Exit(3)
	}
}
