package main

//gooo:generated:start id="candidateerror://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	return GoooComposedActivity0Call0(input)
}
func GoooComposedActivity0Call0(input int64) int64 {
	if input == 0 {
		return 0
	}
	return input / input
}

//gooo:generated:end id="candidateerror://activity/main" kind="activity"
