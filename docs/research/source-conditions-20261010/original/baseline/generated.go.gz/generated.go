package main

//gooo:generated:start id="callerpaths://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	return GoooComposedActivity0Call0(input) + input
}
func GoooComposedActivity0Call0(input int64) int64 {
	if 0 < input {
		return input
	} else {
		return (0 - input)
	}
}

//gooo:generated:end id="callerpaths://activity/main" kind="activity"
